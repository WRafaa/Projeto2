﻿using DAL;
using DataEntity;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Diagnostics.Eventing.Reader;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace LoginRegister
{
    public partial class FrmCriarEmpresas : Form
    {
        int codigo;
        bool edita;
        public FrmCriarEmpresas()
        {
            InitializeComponent();
        }
        public FrmCriarEmpresas(int codigo, bool edita)
        {
            InitializeComponent();
            this.codigo = codigo;
            this.edita = edita;
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void bttinserir_Click(object sender, EventArgs e)
        {
            if (txtmorada.Text != "" && txtnome.Text != "")
            {
                int idcon = EmpregadosDAL.CodigoContacto(cbempresa.Text);
                string sql = "SELECT COUNT(*) FROM Empresa WHERE id_contacto = @idContato";
                using (SqlConnection conn = new SqlConnection(BDDAL.Connectionstring))
                {
                    try
                    {
                        SqlCommand command = new SqlCommand(sql, conn);
                        conn.Open();
                        command.Parameters.AddWithValue("@idContato", idcon);
                        int count = (int)command.ExecuteScalar();
                        if (count > 0)
                        {
                            MessageBox.Show("O contacto escolhido ja pertence a um/a Emprepado/Empresa");
                        }
                        else
                        {
                            try
                            {
                                Empresas E = new Empresas(txtnome.Text, txtmorada.Text, EmpresasDAL.CodigoContacto(cbempresa.Text));
                                EmpresasDAL.InserirEmpresa(E);
                                MessageBox.Show("Dados introduzidos");
                                this.Close();
                            }
                            catch (ArgumentException)
                            {
                                MessageBox.Show("Valor invalido \nPreecha o campo ");
                            }
                            catch (SqlException ex)
                            {
                                MessageBox.Show(ex.ToString());
                            }
                        }
                    }
                    catch (ArgumentException)
                    {
                        MessageBox.Show("Valor invalido ");
                    }
                    catch (SqlException ex)
                    {
                        MessageBox.Show(ex.ToString());
                    }

                }
            }
            else
            {
                MessageBox.Show("Preencha todos os campos");
            }



        }

        private void bttapagar_Click(object sender, EventArgs e)
        {
            DialogResult resposta;
            resposta = MessageBox.Show("Deseja eliminar a Empresa " + txtnome.Text, "Confirmação", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
            if (resposta == DialogResult.Yes)
            {
                try
                {
                    EmpresasDAL.EliminarEmpresa(int.Parse(lbid.Text));
                    MessageBox.Show("Eliminou as informações da Empresa " + txtnome.Text);
                    this.Close();
                }
                catch (SqlException)
                {
                    MessageBox.Show("Erro ao eliminar a empresa\n ");
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message);
                }

            }
        }
        private void BotaoE(bool v)
        {
            bttapagar.Enabled = v;
        }
        private void PreencherCombo()
        {
            List<string> listcon = new List<string>();

            try
            {
                listcon = EmpregadosDAL.ComboContacto();
            }
            catch (SqlException ex)
            {
                MessageBox.Show(ex.Message);
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }


            if (listcon != null)
            {
                cbempresa.DataSource = listcon;
            }

        }
        private void FrmCriarEmpresas_Load(object sender, EventArgs e)
        {
            PreencherCombo();
            if (lbid.Text != "" && edita)
            {
                BotaoE(true);
                this.Text = "Atualização da Empresa";
                this.bttinserir.Text = "Atualizar";
                lbid.Text = codigo.ToString();
                txtnome.Enabled = false;
                txtmorada.Enabled = false;
                cbempresa.Enabled = false;
                bttinserir.Enabled = false;
                PreencherDadosD();
            }
            else
            {
                BotaoE(false);
            }
        }
        private void PreencherDadosD()
        {
            try
            {
                List<Empresas> list = EmpresasDAL.ConsultarCodigo(codigo);
                //a lista contem apenas um registo
                txtnome.Text = list[0].Nome;
                txtmorada.Text = list[0].Morada;

            }
            catch (SqlException ex)
            {
                MessageBox.Show(ex.Message);
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

    }
}
