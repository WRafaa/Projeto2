﻿using DAL;
using DataEntity;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace LoginRegister
{
    public partial class FrmCriarContacto : Form
    {
         public List<string> listtipo=new List<string>();
        public FrmCriarContacto()
        {
            InitializeComponent();

        }
        int id;
        bool edita;
        public FrmCriarContacto(int id,bool edita)
        {
            InitializeComponent();
            this.id = id;
            this.edita = edita;
        }

        private void bttinserir_Click(object sender, EventArgs e)
        {
            if(txtcontacto!=null && textBox1.Text!= null)
            {
              
                string sql = "SELECT COUNT(*) FROM Contacto WHERE Contacto = @Contacto ";
                using (SqlConnection conn = new SqlConnection(BDDAL.Connectionstring))
                {
                    if (!edita)
                    {
                        SqlCommand command = new SqlCommand(sql, conn);
                        conn.Open();
                        command.Parameters.AddWithValue("@Contacto", txtcontacto.Text);
                        int count = (int)command.ExecuteScalar();
                        if(count > 0)
                        {
                            MessageBox.Show("Contacto existente");
                        }
                        else
                        {
                            try
                            {
                                Contactos c = new Contactos(textBox1.Text, txtcontacto.Text);
                                ContactoDAL.InserirContacto(c);
                                MessageBox.Show("Dados introduzidos");
                                this.Close();
                            }
                            catch (ArgumentException)
                            {
                                MessageBox.Show("Valor invalido \nPreecha o campo ");
                            }
                            catch (SqlException ex)
                            {
                                MessageBox.Show(ex.ToString());
                            }
                        }
                        
                    }
                    else
                    {
                        SqlCommand command = new SqlCommand(sql, conn);
                        conn.Open();
                        command.Parameters.AddWithValue("@Contacto", txtcontacto.Text);
                        int count = (int)command.ExecuteScalar();
                        if (count > 0)
                        {
                            MessageBox.Show("Contacto existente");
                        }
                        else
                        {
                            Contactos c = new Contactos(int.Parse(lbid.Text), textBox1.Text, txtcontacto.Text);
                            ContactoDAL.AtualizarContacto(c);
                            MessageBox.Show("Dados atualizados");
                            this.Close();
                        }
 
                    }
                }
                
            }
            else
            {
                MessageBox.Show("Preencha os dados todos");
            }


        }
        private void PreencherDados()
        {
            try
            {
                List<Contactos> list = ContactoDAL.ConsultarCodigo(id) ;
                //a lista contem apenas um registo
                textBox1.Text = list[0].Tipo;
                txtcontacto.Text = list[0].Contacto;

            }
            catch (SqlException ex)
            {
                MessageBox.Show(ex.Message);
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }
        private void Combo()
        {
            List<string> list = new List<string>();
            list.Add("Gmail");
            list.Add("Hotmail");
            list.Add("Telefone");
            foreach (string f in list)
            {
                textBox1.Items.Add(f);
            }
            textBox1.SelectedIndex = 0;
        }
        private void FrmCriarContacto_Load(object sender, EventArgs e)
        {

            Combo();
            if (lbid.Text != "" && edita == true)
            {
                BotaoE(true);
                this.Text = "Atualização do Contacto";
                this.bttinserir.Text = "Atualizar";
                lbid.Text = id.ToString();
                PreencherDados();
                textBox1.Enabled = false;
            }
            else
            {
                BotaoE(false);
            }
        }
        private void BotaoE(bool v)
        {
            bttapagar.Enabled = v;
        }
        private void bttnovotipo_Click(object sender, EventArgs e)
        {
           
        }

        private void bttapagar_Click(object sender, EventArgs e)
        {
            DialogResult resposta;
            resposta = MessageBox.Show("Deseja eliminar o Contacto " + textBox1.Text, "Confirmação", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
            if (resposta == DialogResult.Yes)
            {
                try
                {
                    ContactoDAL.EliminarContacto(int.Parse(lbid.Text));
                    MessageBox.Show("Eliminou as informações do Contacto  " + textBox1.Text);
                    this.Close();
                }
                catch (SqlException)
                {
                    MessageBox.Show("Erro ao eliminar o Contacto\n ");
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message);
                }

            }
        }
    }
}
