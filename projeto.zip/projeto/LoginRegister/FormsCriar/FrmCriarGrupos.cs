﻿using DAL;
using DataEntity;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace LoginRegister
{
    public partial class FrmCriarGrupos : Form
    {
        int id;
        bool edita;
        public FrmCriarGrupos()
        {
            InitializeComponent();
        }

        public FrmCriarGrupos(int id,bool edita)
        {
            InitializeComponent();
            this.id = id;
            this.edita = edita;
        }

        private void bttinserir_Click(object sender, EventArgs e)
        {
            if (textBox1.Text != "")
            {
                if(!edita)
                {
                    try
                    {
                        Grupos g = new Grupos(textBox1.Text);
                        GruposDAL.InserirGrupo(g);
                        MessageBox.Show("Dados introduzidos");
                        this.Close();
                    }
                    catch (ArgumentException)
                    {
                        MessageBox.Show("Valor invalido \nPreecha o campo ");
                    }
                    catch (SqlException ex)
                    {
                        MessageBox.Show(ex.ToString());
                    }
                }
                else
                {
                    try
                    {
                        Grupos g = new Grupos(int.Parse(lbid.Text),textBox1.Text);
                        GruposDAL.Atualizargrupo(g);
                        MessageBox.Show("Dados atualizados");
                        this.Close();
                    }
                    catch (ArgumentException)
                    {
                        MessageBox.Show("Valor invalido \nPreecha o campo ");
                    }
                    catch (SqlException ex)
                    {
                        MessageBox.Show(ex.ToString());
                    }
                }
               
            }
            else
            {
                MessageBox.Show("Preencha todos os campos");
            }
             
            
        }

        private void bttapagar_Click(object sender, EventArgs e)
        {
            DialogResult resposta;
            resposta = MessageBox.Show("Deseja eliminar o Grupo " + textBox1.Text , "Confirmação", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
            if (resposta == DialogResult.Yes)
            {
                try
                {
                    GruposDAL.EliminarGrupo(int.Parse(lbid.Text));
                    MessageBox.Show("Eliminou as informações do Grupo  " + textBox1.Text);
                    this.Close();
                }
                catch (SqlException)
                {
                    MessageBox.Show("Erro ao eliminar o Grupo\n ");
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message);
                }

            }
        }
        private void BotaoE(bool v)
        {
            bttapagar.Enabled = v;
        }

        private void FrmCriarGrupos_Load(object sender, EventArgs e)
        {
            if (lbid.Text != "" && edita == true)
            {
                BotaoE(true);
                this.Text = "Atualização do Grupo";
                this.bttinserir.Text = "Atualizar";
                lbid.Text = id.ToString();
                PreencherDadosD();
            }
            else
            {
                BotaoE(false);
            }
        }
        private void PreencherDadosD()
        {
            try
            {
                List<Grupos> list = GruposDAL.ConsultarCodigo(id); 
                //a lista contem apenas um registo
                textBox1.Text = list[0].Designacao;

            }
            catch (SqlException ex)
            {
                MessageBox.Show(ex.Message);
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }
    }
}
