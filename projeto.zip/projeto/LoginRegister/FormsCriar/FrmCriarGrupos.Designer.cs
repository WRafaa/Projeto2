﻿namespace LoginRegister
{
    partial class FrmCriarGrupos
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.bttinserir = new System.Windows.Forms.Button();
            this.bttapagar = new System.Windows.Forms.Button();
            this.label2 = new System.Windows.Forms.Label();
            this.lbid = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // textBox1
            // 
            this.textBox1.Location = new System.Drawing.Point(82, 53);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(245, 20);
            this.textBox1.TabIndex = 0;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(12, 53);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(64, 13);
            this.label1.TabIndex = 1;
            this.label1.Text = "Designação";
            // 
            // bttinserir
            // 
            this.bttinserir.Location = new System.Drawing.Point(244, 89);
            this.bttinserir.Name = "bttinserir";
            this.bttinserir.Size = new System.Drawing.Size(83, 30);
            this.bttinserir.TabIndex = 2;
            this.bttinserir.Text = "Inserir";
            this.bttinserir.UseVisualStyleBackColor = true;
            this.bttinserir.Click += new System.EventHandler(this.bttinserir_Click);
            // 
            // bttapagar
            // 
            this.bttapagar.BackColor = System.Drawing.Color.LightCoral;
            this.bttapagar.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.bttapagar.ForeColor = System.Drawing.SystemColors.ControlText;
            this.bttapagar.Location = new System.Drawing.Point(144, 89);
            this.bttapagar.Name = "bttapagar";
            this.bttapagar.Size = new System.Drawing.Size(83, 30);
            this.bttapagar.TabIndex = 3;
            this.bttapagar.Text = "Eliminar";
            this.bttapagar.UseVisualStyleBackColor = false;
            this.bttapagar.Click += new System.EventHandler(this.bttapagar_Click);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(26, 20);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(16, 13);
            this.label2.TabIndex = 4;
            this.label2.Text = "Id";
            // 
            // lbid
            // 
            this.lbid.AutoSize = true;
            this.lbid.Location = new System.Drawing.Point(79, 20);
            this.lbid.Name = "lbid";
            this.lbid.Size = new System.Drawing.Size(27, 13);
            this.lbid.TabIndex = 5;
            this.lbid.Text = "N/A";
            // 
            // FrmCriarGrupos
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(339, 128);
            this.Controls.Add(this.lbid);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.bttapagar);
            this.Controls.Add(this.bttinserir);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.textBox1);
            this.Name = "FrmCriarGrupos";
            this.ShowIcon = false;
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent;
            this.Text = "Grupos";
            this.Load += new System.EventHandler(this.FrmCriarGrupos_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button bttinserir;
        private System.Windows.Forms.Button bttapagar;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label lbid;
    }
}