﻿namespace LoginRegister
{
    partial class FrmCriarContactoEmp
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.cbgrupo = new System.Windows.Forms.ComboBox();
            this.bttapagar = new System.Windows.Forms.Button();
            this.bttinserir = new System.Windows.Forms.Button();
            this.lbid = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.cbemp = new System.Windows.Forms.ComboBox();
            this.label2 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // cbgrupo
            // 
            this.cbgrupo.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cbgrupo.FormattingEnabled = true;
            this.cbgrupo.Location = new System.Drawing.Point(83, 92);
            this.cbgrupo.Name = "cbgrupo";
            this.cbgrupo.Size = new System.Drawing.Size(121, 21);
            this.cbgrupo.TabIndex = 22;
            // 
            // bttapagar
            // 
            this.bttapagar.BackColor = System.Drawing.Color.LightCoral;
            this.bttapagar.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.bttapagar.ForeColor = System.Drawing.SystemColors.ControlText;
            this.bttapagar.Location = new System.Drawing.Point(99, 140);
            this.bttapagar.Name = "bttapagar";
            this.bttapagar.Size = new System.Drawing.Size(83, 30);
            this.bttapagar.TabIndex = 21;
            this.bttapagar.Text = "Eliminar";
            this.bttapagar.UseVisualStyleBackColor = false;
            // 
            // bttinserir
            // 
            this.bttinserir.Location = new System.Drawing.Point(205, 140);
            this.bttinserir.Name = "bttinserir";
            this.bttinserir.Size = new System.Drawing.Size(83, 30);
            this.bttinserir.TabIndex = 20;
            this.bttinserir.Text = "Inserir";
            this.bttinserir.UseVisualStyleBackColor = true;
            this.bttinserir.Click += new System.EventHandler(this.bttinserir_Click);
            // 
            // lbid
            // 
            this.lbid.AutoSize = true;
            this.lbid.Location = new System.Drawing.Point(80, 16);
            this.lbid.Name = "lbid";
            this.lbid.Size = new System.Drawing.Size(27, 13);
            this.lbid.TabIndex = 19;
            this.lbid.Text = "N/A";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(17, 95);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(36, 13);
            this.label4.TabIndex = 16;
            this.label4.Text = "Grupo";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(17, 16);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(16, 13);
            this.label1.TabIndex = 13;
            this.label1.Text = "Id";
            // 
            // cbemp
            // 
            this.cbemp.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cbemp.FormattingEnabled = true;
            this.cbemp.Location = new System.Drawing.Point(83, 51);
            this.cbemp.Name = "cbemp";
            this.cbemp.Size = new System.Drawing.Size(121, 21);
            this.cbemp.TabIndex = 24;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(17, 54);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(61, 13);
            this.label2.TabIndex = 23;
            this.label2.Text = "Empregado";
            // 
            // FrmCriarContactoEmp
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(300, 176);
            this.Controls.Add(this.cbemp);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.cbgrupo);
            this.Controls.Add(this.bttapagar);
            this.Controls.Add(this.bttinserir);
            this.Controls.Add(this.lbid);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label1);
            this.Name = "FrmCriarContactoEmp";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent;
            this.Text = "Contactos Empregado";
            this.Load += new System.EventHandler(this.FrmCriarContactoEmp_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.ComboBox cbgrupo;
        private System.Windows.Forms.Button bttapagar;
        private System.Windows.Forms.Button bttinserir;
        private System.Windows.Forms.Label lbid;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.ComboBox cbemp;
        private System.Windows.Forms.Label label2;
    }
}