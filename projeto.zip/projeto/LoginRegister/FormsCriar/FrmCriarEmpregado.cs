﻿using DAL;
using DataEntity;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Drawing.Imaging;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace LoginRegister
{
    public partial class FrmCriarEmpregado : Form
    {
        int codigoemp;
        bool edita;
        public FrmCriarEmpregado(int cod, bool edita)
        {
            this.codigoemp = cod;
            this.edita = edita;
            InitializeComponent();
        }
        public FrmCriarEmpregado()
        {

            InitializeComponent();
        }
        private void BotaoE(bool v)
        {
            bttapagar.Enabled = v;
        }
        private void FrmCriarEmpregado_Load(object sender, EventArgs e)
        {
            PreencherCombo();
            if (lbid.Text != "" && edita)
            {
                BotaoE(true);
                this.Text = "Atualização da Empresa";
                this.bttguardar.Text = "Atualizar";
                lbid.Text = codigoemp.ToString();
                txtpnome.Enabled = false;
                txtunome.Enabled = false;
                PreencherDadosD();
            }
            else
            {
                BotaoE(false);
            }
        }
        private void PreencherDadosD()
        {
            try
            {
                List<Empregado> list = EmpregadosDAL.ConsultarCodigo(codigoemp);
                //a lista contem apenas um registo
                txtpnome.Text = list[0].Pnome;
                txtunome.Text = list[0].Unome;
                txtmorada.Text = list[0].Morada;
                cbcontacto.Text = EmpregadosDAL.Contactoinfo(codigoemp);
                cbempresa.Text = EmpregadosDAL.NomeEmpresa(codigoemp);
            }
            catch (SqlException ex)
            {
                MessageBox.Show(ex.Message);
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }
        private void PreencherCombo()
        {
            List<string> listempresa = new List<string>();
            List<string> listcon = new List<string>();

            try
            {
                listempresa = EmpregadosDAL.ComboEmpresa();
                listcon = EmpregadosDAL.ComboContacto();
            }
            catch (SqlException ex)
            {
                MessageBox.Show(ex.Message);
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }

            if (listempresa != null)
            {
                cbempresa.DataSource = listempresa;
            }
            if (listcon != null)
            {
                cbcontacto.DataSource = listcon;
            }

        }

        private void label6_Click(object sender, EventArgs e)
        {

        }

        private void bttguardar_Click(object sender, EventArgs e)
        {
            if (txtmorada.Text != "" && txtpnome.Text != "" && txtunome.Text != "")
            {
                
                int idcon = EmpregadosDAL.CodigoContacto(cbcontacto.Text);
                string sql = "SELECT COUNT(*) FROM Empregado  WHERE id_contacto = @idContato ";
                using (SqlConnection conn = new SqlConnection(BDDAL.Connectionstring))
                {
                    try
                    {
                        if (!edita)
                        {
                            try
                            {
                                SqlCommand command = new SqlCommand(sql, conn);
                                conn.Open();
                                command.Parameters.AddWithValue("@idContato", idcon);
                                int count = (int)command.ExecuteScalar();
                                if (count > 0)
                                {
                                    MessageBox.Show("O contacto escolhido ja pertence a um/a Emprepado/Empresa");
                                }
                                else
                                {
                                    try
                                    {
                                        Empregado ep = new Empregado(txtpnome.Text, txtunome.Text, txtmorada.Text, EmpregadosDAL.CodigoEmp(cbempresa.Text), EmpregadosDAL.CodigoContacto(cbcontacto.Text)); ;
                                        EmpregadosDAL.InserirEmpregado(ep);
                                        MessageBox.Show("Dados introduzidos");
                                        this.Close();
                                    }
                                    catch (ArgumentException)
                                    {
                                        MessageBox.Show("Valor invalido \nPreecha o campo ");
                                    }
                                    catch (SqlException ex)
                                    {
                                        MessageBox.Show(ex.ToString());
                                    }

                                }

                            }
                            catch (ArgumentException)
                            {
                                MessageBox.Show("Valor invalido \nPreecha o campo ");
                            }
                            catch (SqlException ex)
                            {
                                MessageBox.Show(ex.ToString());
                            }
                        }
                        else
                        {
                            int id = int.Parse(lbid.Text);
                            string sqledita = "SELECT COUNT(*) FROM Empregado WHERE id_contacto = @idContato and id_empregado <> @idemp";
                            SqlCommand command = new SqlCommand(sqledita, conn);
                            conn.Open();
                            command.Parameters.AddWithValue("@idContato", idcon);
                            command.Parameters.AddWithValue("@idemp", id);                
                            int count = (int)command.ExecuteScalar();
                            if (count > 0)
                            {
                                MessageBox.Show("O contacto escolhido ja pertence a um/a Emprepado/Empresa");
                            }
                            else
                            {
                                try
                                {
                                    Empregado ep = new Empregado(id, txtpnome.Text, txtunome.Text, txtmorada.Text, EmpregadosDAL.CodigoEmp(cbempresa.Text), EmpregadosDAL.CodigoContacto(cbcontacto.Text));
                                    EmpregadosDAL.AtualizarEmpregado(ep);
                                    MessageBox.Show("Dados atualizados");
                                    this.Close();
                                }
                                catch (ArgumentException)
                                {
                                    MessageBox.Show("Valor invalido \nPreecha o campo ");
                                }
                                catch (SqlException ex)
                                {
                                    MessageBox.Show(ex.ToString());
                                }
                            }

                        }


                    }
                    catch (ArgumentException)
                    {
                        MessageBox.Show("Valor invalido \nPreecha o campo ");
                    }
                    catch (SqlException ex)
                    {
                        MessageBox.Show(ex.ToString());
                    }
                }




            }
            else
            {
                MessageBox.Show("Preencha os campos todos");
            }

        }

        private void checkBox1_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void bttapagar_Click(object sender, EventArgs e)
        {
            DialogResult resposta;
            resposta = MessageBox.Show("Deseja eliminar as informacoes do empregado ", "Confirmação", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
            if (resposta == DialogResult.Yes)
            {
                try
                {

                    EmpregadosDAL.EliminarEmpregado(int.Parse(lbid.Text));
                    MessageBox.Show("Eliminou as informações do empregado " + txtpnome.Text);
                    this.Close();
                }
                catch (SqlException )
                {
                    MessageBox.Show("Erro ao eliminar Empregado");
                }
                catch (Exception)
                {
                    MessageBox.Show("Erro ao eliminar Empregado");
                }

            }
        }

        private void txtpnome_KeyPress(object sender, KeyPressEventArgs e)
        {
          
        }
    }
}
