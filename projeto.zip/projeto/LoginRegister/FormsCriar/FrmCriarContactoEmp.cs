﻿using DAL;
using DataEntity;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace LoginRegister
{
    public partial class FrmCriarContactoEmp : Form
    {
        public FrmCriarContactoEmp()
        {
            InitializeComponent();
            PreencherCombo();
        }
        private void PreencherCombo()
        {
            List<string> listemp = new List<string>();
            List<string> listgrupo = new List<string>();

            try
            {
                listemp = ContactosEmpresaDAL.ComboEmp();
                listgrupo=ContactosEmpresaDAL.ComboGrupo();
            }
            catch (SqlException ex)
            {
                MessageBox.Show(ex.Message);
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }


            if (listemp != null)
            {
                cbemp.DataSource = listemp;
            }
            if (listgrupo != null)
            {
                cbgrupo.DataSource = listgrupo;
            }

        }
        private void FrmCriarContactoEmp_Load(object sender, EventArgs e)
        {

        }

        private void bttinserir_Click(object sender, EventArgs e)
        {
            try
            {
                ContactosEmpresa E = new ContactosEmpresa(ContactosEmpresaDAL.CodigoEmp(cbemp.Text),ContactosEmpresaDAL.CodigoGrupo(cbgrupo.Text));
                ContactosEmpresaDAL.InserirEmpGrupo(E);
                MessageBox.Show("Dados introduzidos");
                this.Close();
            }
            catch (ArgumentException)
            {
                MessageBox.Show("Valor invalido \nPreecha o campo ");
            }
            catch (SqlException ex)
            {
                MessageBox.Show(ex.ToString());
            }
        }
    }
}
