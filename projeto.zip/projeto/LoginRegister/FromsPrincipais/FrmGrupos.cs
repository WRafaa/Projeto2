﻿using DataEntity;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using DAL;

namespace LoginRegister
{
    public partial class FrmGrupos : Form
    {
        public FrmGrupos()
        {
            InitializeComponent();
        }

        private void bttnovo_Click(object sender, EventArgs e)
        {
            FrmCriarGrupos g=new FrmCriarGrupos();
            g.ShowDialog();
            AtualizarGrelha();
        }
        private void AtualizarGrelha()
        {
            try
            {
                List<Grupos> lst = GruposDAL.Consultar();
                PreencherGrelha(lst);
                dgv.ClearSelection();

            }
            catch (SqlException ex)
            {
                MessageBox.Show(ex.ToString());
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString());
            }
        }
        private void PreencherGrelha(List<Grupos> lst)
        {
            dgv.DataSource = lst;
            dgv.Columns[0].HeaderText = "ID";
            dgv.Columns[0].Width = 75;
            dgv.Columns[1].HeaderText = "Designação";
            dgv.Columns[1].Width = 272;


            dgv.ColumnHeadersDefaultCellStyle.Font = new Font(Font, FontStyle.Bold);
            dgv.AlternatingRowsDefaultCellStyle.BackColor = Color.Silver;
            dgv.AutoSizeRowsMode = DataGridViewAutoSizeRowsMode.AllCells;
            dgv.AllowUserToAddRows = false;
            dgv.AllowUserToResizeColumns = false;
            dgv.ReadOnly = true;
        }
        private void FrmGrupos_Load(object sender, EventArgs e)
        {
            AtualizarGrelha();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (dgv.Rows.Count > 0)
            {
                int linha = dgv.CurrentRow.Index;
                int codigo = int.Parse(dgv[0, linha].Value.ToString());
                bool edita = true;
                FrmCriarGrupos g = new FrmCriarGrupos(codigo, edita);
                g.ShowDialog();
                AtualizarGrelha();

            }
        }

        private void dgv_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }
    }
}
