﻿using DAL;
using DataEntity;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace LoginRegister
{
    public partial class FrmEmpresas : Form
    {
        public FrmEmpresas()
        {
            InitializeComponent();
        }

        private void FrmEmpresas_Load(object sender, EventArgs e)
        {
            AtualizarGrelha();
        }
        private void AtualizarGrelha()
        {
            try
            {
                SqlConnection conn = new SqlConnection(BDDAL.Connectionstring);
                SqlCommand cmd = new SqlCommand("select * from View3", conn);
                SqlDataAdapter da = new SqlDataAdapter(cmd);
                DataTable dt = new DataTable();
                da.Fill(dt);
                dgv.DataSource = dt;
                this.dgv.Columns["Morada_Empresa"].HeaderText = "Morada Empresa";
                this.dgv.Columns["Nome_Empresa"].HeaderText = "Empresa";
                this.dgv.Columns["Morada_Empresa"].HeaderText = "Morada Empresa";
                dgv.AllowUserToAddRows = false;
            }
            catch (SqlException)
            {
                MessageBox.Show("Erro na base de dados");
            }
            catch (Exception ) 
            {
                MessageBox.Show("Erro no dados");
            }
            
           
        }
       
       
        private void bttnovo_Click(object sender, EventArgs e)
        {
            FrmCriarEmpresas fe = new FrmCriarEmpresas();
            fe.ShowDialog();
            AtualizarGrelha();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (dgv.Rows.Count > 0)
            {
                int linha = dgv.CurrentRow.Index;
                int codigo = int.Parse(dgv[0, linha].Value.ToString());
                bool edita = true;
                FrmCriarEmpresas fe = new FrmCriarEmpresas(codigo, edita);
                fe.ShowDialog();
                AtualizarGrelha();

            }
        }
    }
}
