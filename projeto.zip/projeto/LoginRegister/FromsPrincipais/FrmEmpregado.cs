﻿using DAL;
using DataEntity;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;


namespace LoginRegister
{
    public partial class FrmEmpregado : Form
    {
        public FrmEmpregado()
        {
            InitializeComponent();
        }
        int codigoemp;
        string nomelinha;
        private void FrmEmpregado_Load(object sender, EventArgs e)
        {
            AtualizarGrelha();
            lbn.Text=EmpregadosDAL.ContarEmpOrg().ToString();   
        }
        private void AtualizarGrelha()
        {
            SqlConnection conn = new SqlConnection(BDDAL.Connectionstring);
            SqlCommand cmd = new SqlCommand("select * from View2", conn);
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            DataTable dt = new DataTable();
            
            da.Fill(dt);
            dgv.DataSource = dt;
            this.dgv.Columns["P_Nome"].HeaderText = "Nome";
            this.dgv.Columns["Nome_Empresa"].HeaderText = "Empresa";
            this.dgv.Columns["morada_Empresa"].HeaderText = "Morada Empresa";
            dgv.AllowUserToAddRows = false;
        }

        private void bttnovo_Click(object sender, EventArgs e)
        {
            FrmCriarEmpregado n=new FrmCriarEmpregado();
            n.ShowDialog();
            AtualizarGrelha();
            lbn.Text = EmpregadosDAL.ContarEmpOrg().ToString();
        }

        private void dgv_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            if (dgv.Rows.Count > 0)
            {
                int linha = dgv.CurrentRow.Index;
               codigoemp = int.Parse(dgv[0, linha].Value.ToString());
                nomelinha = dgv[1, linha].ToString();
               

            }
        }

        private void bttatualizar_Click(object sender, EventArgs e)
        {
            if (dgv.Rows.Count > 0)
            {
                int linha = dgv.CurrentRow.Index;
                int codigo = int.Parse(dgv[0, linha].Value.ToString());
                bool edita = true;
                FrmCriarEmpregado fe = new FrmCriarEmpregado(codigo, edita);
                fe.ShowDialog();
                AtualizarGrelha();

            }
        }
    }
}
