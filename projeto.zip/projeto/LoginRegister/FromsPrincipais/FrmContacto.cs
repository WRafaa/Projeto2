﻿using DAL;
using DataEntity;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace LoginRegister
{
    public partial class FrmContacto : Form
    {
        public FrmContacto()
        {
            InitializeComponent();
        }

        private void bttnovo_Click(object sender, EventArgs e)
        {
            FrmCriarContacto fc=new FrmCriarContacto();
            fc.ShowDialog();
            AtualizarGrelha();
        }
        private void AtualizarGrelha()
        {
            try
            {
                List<Contactos> lst = ContactoDAL.Consultar();
                PreencherGrelha(lst);
                dgv.ClearSelection();

            }
            catch (SqlException ex)
            {
                MessageBox.Show(ex.ToString());
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString());
            }
        }
        private void PreencherGrelha(List<Contactos> lst)
        {
            dgv.DataSource = lst;
            dgv.Columns[0].HeaderText = "ID";
            dgv.Columns[0].Width = 75;
            dgv.Columns[1].HeaderText = "Tipo Contacto";
            dgv.Columns[1].Width = 160;


            dgv.ColumnHeadersDefaultCellStyle.Font = new Font(Font, FontStyle.Bold);
            dgv.AlternatingRowsDefaultCellStyle.BackColor = Color.Silver;
            dgv.AutoSizeRowsMode = DataGridViewAutoSizeRowsMode.AllCells;
            dgv.AllowUserToAddRows = false;
            dgv.AllowUserToResizeColumns = false;
            dgv.ReadOnly = true;
        }
        private void FrmContacto_Load(object sender, EventArgs e)
        {
            AtualizarGrelha();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (dgv.Rows.Count > 0)
            {
                int linha = dgv.CurrentRow.Index;
                int codigo = int.Parse(dgv[0, linha].Value.ToString());
                bool edita = true;
                FrmCriarContacto fr = new FrmCriarContacto(codigo,edita);
                fr.ShowDialog();
                AtualizarGrelha();

            }
        }
    }
}
