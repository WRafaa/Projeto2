﻿namespace LoginRegister
{
    partial class FrmContactosEmp
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.button1 = new System.Windows.Forms.Button();
            this.bttnovo = new System.Windows.Forms.Button();
            this.dgv = new System.Windows.Forms.DataGridView();
            ((System.ComponentModel.ISupportInitialize)(this.dgv)).BeginInit();
            this.SuspendLayout();
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(279, 209);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(75, 32);
            this.button1.TabIndex = 11;
            this.button1.Text = "Atualizar";
            this.button1.UseVisualStyleBackColor = true;
            // 
            // bttnovo
            // 
            this.bttnovo.Location = new System.Drawing.Point(375, 209);
            this.bttnovo.Name = "bttnovo";
            this.bttnovo.Size = new System.Drawing.Size(75, 32);
            this.bttnovo.TabIndex = 10;
            this.bttnovo.Text = "Novo";
            this.bttnovo.UseVisualStyleBackColor = true;
            this.bttnovo.Click += new System.EventHandler(this.bttnovo_Click);
            // 
            // dgv
            // 
            this.dgv.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgv.Location = new System.Drawing.Point(17, 16);
            this.dgv.Name = "dgv";
            this.dgv.Size = new System.Drawing.Size(433, 187);
            this.dgv.TabIndex = 9;
            // 
            // FrmContactosEmp
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(462, 253);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.bttnovo);
            this.Controls.Add(this.dgv);
            this.Name = "FrmContactosEmp";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent;
            this.Text = "Contactos Empregado";
            this.Load += new System.EventHandler(this.FrmContactosEmp_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dgv)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button bttnovo;
        private System.Windows.Forms.DataGridView dgv;
    }
}