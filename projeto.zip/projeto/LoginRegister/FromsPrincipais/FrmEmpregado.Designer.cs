﻿namespace LoginRegister
{
    partial class FrmEmpregado
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.dgv = new System.Windows.Forms.DataGridView();
            this.bttnovo = new System.Windows.Forms.Button();
            this.bttatualizar = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.lbn = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.dgv)).BeginInit();
            this.SuspendLayout();
            // 
            // dgv
            // 
            this.dgv.AllowUserToAddRows = false;
            this.dgv.AllowUserToDeleteRows = false;
            this.dgv.AllowUserToResizeColumns = false;
            this.dgv.AllowUserToResizeRows = false;
            this.dgv.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgv.Location = new System.Drawing.Point(12, 12);
            this.dgv.Name = "dgv";
            this.dgv.ReadOnly = true;
            this.dgv.Size = new System.Drawing.Size(538, 223);
            this.dgv.TabIndex = 0;
            this.dgv.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgv_CellContentClick);
            // 
            // bttnovo
            // 
            this.bttnovo.Location = new System.Drawing.Point(454, 255);
            this.bttnovo.Name = "bttnovo";
            this.bttnovo.Size = new System.Drawing.Size(89, 33);
            this.bttnovo.TabIndex = 1;
            this.bttnovo.Text = "Novo";
            this.bttnovo.UseVisualStyleBackColor = true;
            this.bttnovo.Click += new System.EventHandler(this.bttnovo_Click);
            // 
            // bttatualizar
            // 
            this.bttatualizar.Location = new System.Drawing.Point(349, 255);
            this.bttatualizar.Name = "bttatualizar";
            this.bttatualizar.Size = new System.Drawing.Size(89, 33);
            this.bttatualizar.TabIndex = 2;
            this.bttatualizar.Text = "Atualizar";
            this.bttatualizar.UseVisualStyleBackColor = true;
            this.bttatualizar.Click += new System.EventHandler(this.bttatualizar_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(5, 268);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(139, 20);
            this.label1.TabIndex = 3;
            this.label1.Text = "Nº Empregados:";
            // 
            // lbn
            // 
            this.lbn.AutoSize = true;
            this.lbn.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold);
            this.lbn.Location = new System.Drawing.Point(150, 268);
            this.lbn.Name = "lbn";
            this.lbn.Size = new System.Drawing.Size(19, 20);
            this.lbn.TabIndex = 4;
            this.lbn.Text = "0";
            // 
            // FrmEmpregado
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(562, 310);
            this.Controls.Add(this.lbn);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.bttatualizar);
            this.Controls.Add(this.bttnovo);
            this.Controls.Add(this.dgv);
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "FrmEmpregado";
            this.Text = "Empregados";
            this.Load += new System.EventHandler(this.FrmEmpregado_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dgv)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.DataGridView dgv;
        private System.Windows.Forms.Button bttnovo;
        private System.Windows.Forms.Button bttatualizar;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label lbn;
    }
}