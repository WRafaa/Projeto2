﻿using DAL;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace LoginRegister
{
    public partial class FrmContactosEmp : Form
    {
        public FrmContactosEmp()
        {
            InitializeComponent();
        }

        private void bttnovo_Click(object sender, EventArgs e)
        {
            FrmCriarContactoEmp f=new FrmCriarContactoEmp();
            f.ShowDialog();
            AtualizarGrelha();
        }
        private void AtualizarGrelha()
        {
            SqlConnection conn = new SqlConnection(BDDAL.Connectionstring);
            SqlCommand cmd = new SqlCommand("select * from View4", conn);
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            DataTable dt = new DataTable();
            da.Fill(dt);
            dgv.DataSource = dt;
            dgv.AllowUserToAddRows = false;
            this.dgv.Columns[0].HeaderText = "Nome";
            this.dgv.Columns[1].HeaderText = "Morada";
            this.dgv.Columns[2].HeaderText = "Morada Empresa";
            this.dgv.Columns[4].HeaderText = "Grupo";
        }
        private void FrmContactosEmp_Load(object sender, EventArgs e)
        {
            AtualizarGrelha();
        }
    }
}
