﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace LoginRegister
{
    public partial class FrmPrimeiro : Form
    {

        //controlar o form que estiver aberto no panel
        FrmGrupos grupo;
        FrmEmpresas empresa;
        FrmContacto con;
        FrmEmpregado emp;
        FrmContactosEmp cemp;
        FrmPesquisar p;
       // private Form frmAtivo;
        string user;

        bool menuexpand = false;
        public FrmPrimeiro(string user)
        {
            InitializeComponent();
            this.user = user;   
        }
       //private void FormMostrar(Form f)
       // {
       //     AtivarFormClose();
       //     frmAtivo = f;
       //     f.TopLevel = false;
       //     panelform.Controls.Add(frmAtivo);
       //     f.BringToFront();
       //     f.Show();
       // }
        //fecha os forms
        //private void AtivarFormClose()
        //{
        //    if(frmAtivo != null)
        //    {
        //        frmAtivo.Close();
        //    }
        //}


        //este metodo coloca o botao que o utilizador clicou fica vermelho e os outros ficam brancos
        //private void AtivarButao(Button frmativo)
        //{
        //    foreach (Control control in panelpricipal.Controls)
        //    {
        //        control.ForeColor = Color.White;
        //    }
        //    frmativo.ForeColor = Color.Red;
        //}
        private void bttgrupo_Click(object sender, EventArgs e)
        {
        }

        private void bttfechar_Click(object sender, EventArgs e)
        {
           
        }

        private void bttempresa_Click(object sender, EventArgs e)
        {
           
        }

        private void bttsair_Click(object sender, EventArgs e)
        {
           Login login = new Login();
            login.Show();
            this.Close();
        }

        private void FrmPrimeiro_Load(object sender, EventArgs e)
        {
            this.Text = user;
        }

        private void button1_Click(object sender, EventArgs e)
        {
          
        }

        private void bttcontacto_Click(object sender, EventArgs e)
        {
           
        }

        private void panelform_Paint(object sender, PaintEventArgs e)
        {

        }

        private void menutranstion_Tick(object sender, EventArgs e)
        {
            if(!menuexpand)
            {
                menucontainer.Height += 10;
                if(menucontainer.Height>= 300)
                {
                    menutranstion.Stop();
                    menuexpand = true;
                }
            }
            else
            {
                menucontainer.Height-= 10;
                if(menucontainer.Height<=53)
                {
                    menutranstion.Stop();
                    menuexpand=false;
                }
            }
        }

        private void menu_Click(object sender, EventArgs e)
        {
            menutranstion.Start();
        }

        private void menu_MouseHover(object sender, EventArgs e)
        {
            
        }

        private void button4_Click(object sender, EventArgs e)
        {
            if (grupo == null)
            {
                grupo = new FrmGrupos();
                grupo.FormClosed += Grupo_FormClosed;
                grupo.MdiParent = this;
                grupo.Show();
            }
            else
            {
                grupo.Activate();
            }
        }

        private void Grupo_FormClosed(object sender, FormClosedEventArgs e)
        {
            grupo = null;
        }

        private void button3_Click(object sender, EventArgs e)
        {
            if (empresa == null)
            {
                empresa = new FrmEmpresas();
                empresa.FormClosed += Empresa_FormClosed;
                empresa.MdiParent = this;
                empresa.Show();
            }
            else
            {
                empresa.Activate();
            }
        }
        private void Empresa_FormClosed(object sender, FormClosedEventArgs e)
        {
            empresa = null;
        }

        private void button1_Click_1(object sender, EventArgs e)
        {
            if (emp == null)
            {
                emp = new FrmEmpregado();
                emp.FormClosed += Emp_FormClosed;
                emp.MdiParent = this;
                emp.Show();
            }
            else
            {
                emp.Activate();
            }
        }

        private void Emp_FormClosed(object sender, FormClosedEventArgs e)
        {
            emp = null;
        }

        private void button2_Click(object sender, EventArgs e)
        {
            if (con == null)
            {
                con = new FrmContacto();
                con.FormClosed += Contacto_FormClosed;
                con.MdiParent = this;
                con.Show();
             
            }
            else
            {
                con.Activate();
            }
        }
        private void Contacto_FormClosed(object sender, FormClosedEventArgs e)
        {
            con = null;
        }

        private void button5_Click(object sender, EventArgs e)
        {
            if (cemp == null)
            {
                cemp = new FrmContactosEmp();
                cemp.FormClosed += Cemp_FormClosed;
                cemp.MdiParent = this;
                cemp.Show();

            }
            else
            {
                cemp.Activate();
            }
        }

        private void Cemp_FormClosed(object sender, FormClosedEventArgs e)
        {
            cemp = null;
        }

        private void button6_Click(object sender, EventArgs e)
        {
            if (p == null)
            {
               p = new FrmPesquisar();
                p.FormClosed += P_FormClosed;
                p.MdiParent = this;
                p.Show();
            }
            else
            {
                p.Activate();
            }
        }

        private void P_FormClosed(object sender, FormClosedEventArgs e)
        {
            p = null;
        }
    }
}
