﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using DAL;

namespace LoginRegister
{
    public partial class Login : Form
    {
        public Login()
        {
            InitializeComponent();
        }

        private void label2_Click(object sender, EventArgs e)
        {
            SignUp s= new SignUp();
            s.ShowDialog();
        }
        private bool ValidarUser(string nome, string user)
        {
            bool existe = true;
            int qtdnome = UtilizadorDAL.ContarUtilizadoresNome(nome);
            if (qtdnome == 0)
            {
                existe = false;
                MessageBox.Show("Utilizador inesxistente");
            }
            else
            {
                int qtdnomepin = UtilizadorDAL.ContarUtilizadoresNomePin(nome, user);
                {
                    if (qtdnomepin == 0)
                    {
                        existe = false;
                        errorProvider1.SetError(txtpass, "Pin invalido");
                    }
                }
            }
            return existe;
        }
        private bool validar()
        {
            bool erro = true;
            errorProvider1.Clear();

            if (txtuser.Text == "")
            {
                erro = false;
                errorProvider1.SetError(txtuser, "Erro no  nome");
            }
            if (txtpass.Text == "")
            {
                erro = false;
                errorProvider1.SetError(txtpass, "Erro na pass");
            }
            if (txtpass.Text != "" && txtuser.Text != "")
            {

                if (!ValidarUser(txtuser.Text, txtpass.Text))
                {
                    erro = false;
                }
            }
            return erro;
        }
        private void Login_Load(object sender, EventArgs e)
        {
            txtuser.Focus();
        }

        private void bttlogin_Click(object sender, EventArgs e)
        {
            if (validar())
            {
                this.Hide();
                FrmPrimeiro form = new FrmPrimeiro(txtuser.Text);
                form.ShowDialog();

            }
        }
    }
}
