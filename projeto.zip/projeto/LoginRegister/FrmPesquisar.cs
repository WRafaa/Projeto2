﻿using DAL;
using DataEntity;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace LoginRegister
{
    public partial class FrmPesquisar : Form
    {
        public FrmPesquisar()
        {
            InitializeComponent();
        }
        private void Combo()
        {
            List<string> list = new List<string>();
            list.Add("Contacto");
            list.Add("Empregado");
            list.Add("Grupo");
            foreach (string f in list)
            {
                comboBox1.Items.Add(f);
            }
            comboBox1.SelectedIndex = 0;
        }
        private void FrmPesquisar_Load(object sender, EventArgs e)
        {
            Combo();
            AtualizarGrelhaTudo();
        }
   
        private void AtualizarGrelhaTudo()
        {
            SqlConnection conn = new SqlConnection(BDDAL.Connectionstring);
            SqlCommand cmd = new SqlCommand("select * from View5", conn);
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            DataTable dt = new DataTable();
            da.Fill(dt);
            dgv.DataSource = dt;
            Grelha();
            dgv.AllowUserToAddRows = false;
        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            AtualizarGrelhaTudo();
        }
        private void Grelha()
        {
            this.dgv.Columns["P_Nome"].HeaderText = "Primeiro Nome";
            this.dgv.Columns["U_Nome"].HeaderText = "Ultimo Nome";
            this.dgv.Columns["Nome_Empresa"].HeaderText = "Empresa";
            this.dgv.Columns["Designacao"].HeaderText = "Grupo";
        }
        private void button1_Click(object sender, EventArgs e)
        {
            
        }
        private DataTable PesquisarEmp()
        {
            SqlConnection conn = new SqlConnection(BDDAL.Connectionstring);
            SqlCommand cmd = new SqlCommand("select * from View5 where P_Nome like '%' +@parm + '%'", conn);
            cmd.Parameters.AddWithValue("parm", textBox1.Text);
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            DataTable dt = new DataTable();
            da.Fill(dt);
            Grelha();
            dgv.DataSource = dt;

            return dt;
        }
        private DataTable PesquisarCon()
        {
            SqlConnection conn = new SqlConnection(BDDAL.Connectionstring);
            SqlCommand cmd = new SqlCommand("select * from View5 where Contacto like '%' +@parm + '%'", conn);
            cmd.Parameters.AddWithValue("parm", textBox1.Text);
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            DataTable dt = new DataTable();
            da.Fill(dt);
            Grelha();
            dgv.DataSource = dt;

            return dt;
        }
        private DataTable PesquisarGrupo()
        {
            SqlConnection conn = new SqlConnection(BDDAL.Connectionstring);
            SqlCommand cmd = new SqlCommand("select * from View5 where Designacao like '%' +@parm + '%'", conn);
            cmd.Parameters.AddWithValue("parm", textBox1.Text);
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            DataTable dt = new DataTable();
            da.Fill(dt);
            Grelha();
            dgv.DataSource = dt;

            return dt;
        }
        private void textBox1_TextChanged(object sender, EventArgs e)
        {
          

        }

        private void textBox1_KeyUp(object sender, KeyEventArgs e)
        {
            switch (comboBox1.SelectedIndex)
            {
                case 0:
                    dgv.DataSource = PesquisarCon();
                    break;

                case 1:

                    dgv.DataSource = PesquisarEmp();
                    break;


                case 2:
                    dgv.DataSource = PesquisarGrupo();
                    break;
            }
            
        }
    }
}
