﻿
namespace LoginRegister
{
    partial class SignUp
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(SignUp));
            this.guna2CircleButton3 = new Guna.UI2.WinForms.Guna2CircleButton();
            this.guna2CircleButton2 = new Guna.UI2.WinForms.Guna2CircleButton();
            this.guna2CircleButton1 = new Guna.UI2.WinForms.Guna2CircleButton();
            this.bttsign = new Guna.UI2.WinForms.Guna2GradientButton();
            this.txtpass1 = new Guna.UI2.WinForms.Guna2TextBox();
            this.txtpnome = new Guna.UI2.WinForms.Guna2TextBox();
            this.picbox1 = new Guna.UI2.WinForms.Guna2PictureBox();
            this.txtunome = new Guna.UI2.WinForms.Guna2TextBox();
            this.txtpass2 = new Guna.UI2.WinForms.Guna2TextBox();
            this.txtuser = new Guna.UI2.WinForms.Guna2TextBox();
            this.errorProvider1 = new System.Windows.Forms.ErrorProvider(this.components);
            ((System.ComponentModel.ISupportInitialize)(this.picbox1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.errorProvider1)).BeginInit();
            this.SuspendLayout();
            // 
            // guna2CircleButton3
            // 
            this.guna2CircleButton3.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(61)))), ((int)(((byte)(0)))));
            this.guna2CircleButton3.BorderThickness = 3;
            this.guna2CircleButton3.CheckedState.Parent = this.guna2CircleButton3;
            this.guna2CircleButton3.CustomImages.Parent = this.guna2CircleButton3;
            this.guna2CircleButton3.FillColor = System.Drawing.Color.Empty;
            this.guna2CircleButton3.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.guna2CircleButton3.ForeColor = System.Drawing.Color.White;
            this.guna2CircleButton3.HoverState.Parent = this.guna2CircleButton3;
            this.guna2CircleButton3.Image = ((System.Drawing.Image)(resources.GetObject("guna2CircleButton3.Image")));
            this.guna2CircleButton3.Location = new System.Drawing.Point(696, 388);
            this.guna2CircleButton3.Name = "guna2CircleButton3";
            this.guna2CircleButton3.ShadowDecoration.Mode = Guna.UI2.WinForms.Enums.ShadowMode.Circle;
            this.guna2CircleButton3.ShadowDecoration.Parent = this.guna2CircleButton3;
            this.guna2CircleButton3.Size = new System.Drawing.Size(64, 59);
            this.guna2CircleButton3.TabIndex = 13;
            // 
            // guna2CircleButton2
            // 
            this.guna2CircleButton2.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(172)))), ((int)(((byte)(237)))));
            this.guna2CircleButton2.BorderThickness = 3;
            this.guna2CircleButton2.CheckedState.Parent = this.guna2CircleButton2;
            this.guna2CircleButton2.CustomImages.Parent = this.guna2CircleButton2;
            this.guna2CircleButton2.FillColor = System.Drawing.Color.Empty;
            this.guna2CircleButton2.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.guna2CircleButton2.ForeColor = System.Drawing.Color.White;
            this.guna2CircleButton2.HoverState.Parent = this.guna2CircleButton2;
            this.guna2CircleButton2.Image = ((System.Drawing.Image)(resources.GetObject("guna2CircleButton2.Image")));
            this.guna2CircleButton2.Location = new System.Drawing.Point(605, 388);
            this.guna2CircleButton2.Name = "guna2CircleButton2";
            this.guna2CircleButton2.ShadowDecoration.Mode = Guna.UI2.WinForms.Enums.ShadowMode.Circle;
            this.guna2CircleButton2.ShadowDecoration.Parent = this.guna2CircleButton2;
            this.guna2CircleButton2.Size = new System.Drawing.Size(64, 59);
            this.guna2CircleButton2.TabIndex = 14;
            // 
            // guna2CircleButton1
            // 
            this.guna2CircleButton1.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(59)))), ((int)(((byte)(89)))), ((int)(((byte)(152)))));
            this.guna2CircleButton1.BorderThickness = 3;
            this.guna2CircleButton1.CheckedState.Parent = this.guna2CircleButton1;
            this.guna2CircleButton1.CustomImages.Parent = this.guna2CircleButton1;
            this.guna2CircleButton1.FillColor = System.Drawing.Color.Empty;
            this.guna2CircleButton1.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.guna2CircleButton1.ForeColor = System.Drawing.Color.White;
            this.guna2CircleButton1.HoverState.Parent = this.guna2CircleButton1;
            this.guna2CircleButton1.Image = ((System.Drawing.Image)(resources.GetObject("guna2CircleButton1.Image")));
            this.guna2CircleButton1.Location = new System.Drawing.Point(512, 388);
            this.guna2CircleButton1.Name = "guna2CircleButton1";
            this.guna2CircleButton1.ShadowDecoration.Mode = Guna.UI2.WinForms.Enums.ShadowMode.Circle;
            this.guna2CircleButton1.ShadowDecoration.Parent = this.guna2CircleButton1;
            this.guna2CircleButton1.Size = new System.Drawing.Size(64, 59);
            this.guna2CircleButton1.TabIndex = 15;
            // 
            // bttsign
            // 
            this.bttsign.Animated = true;
            this.bttsign.AutoRoundedCorners = true;
            this.bttsign.BorderRadius = 22;
            this.bttsign.CheckedState.Parent = this.bttsign;
            this.bttsign.CustomImages.Parent = this.bttsign;
            this.bttsign.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(243)))), ((int)(((byte)(60)))), ((int)(((byte)(40)))));
            this.bttsign.FillColor2 = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(188)))), ((int)(((byte)(44)))));
            this.bttsign.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bttsign.ForeColor = System.Drawing.Color.White;
            this.bttsign.HoverState.Parent = this.bttsign;
            this.bttsign.Location = new System.Drawing.Point(562, 301);
            this.bttsign.Name = "bttsign";
            this.bttsign.ShadowDecoration.Parent = this.bttsign;
            this.bttsign.Size = new System.Drawing.Size(153, 46);
            this.bttsign.TabIndex = 12;
            this.bttsign.Text = "Criar";
            this.bttsign.Click += new System.EventHandler(this.bttsign_Click);
            // 
            // txtpass1
            // 
            this.txtpass1.Animated = true;
            this.txtpass1.AutoRoundedCorners = true;
            this.txtpass1.BorderColor = System.Drawing.SystemColors.ControlDark;
            this.txtpass1.BorderRadius = 22;
            this.txtpass1.BorderThickness = 2;
            this.txtpass1.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.txtpass1.DefaultText = "";
            this.txtpass1.DisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(208)))), ((int)(((byte)(208)))));
            this.txtpass1.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(226)))), ((int)(((byte)(226)))));
            this.txtpass1.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.txtpass1.DisabledState.Parent = this.txtpass1;
            this.txtpass1.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.txtpass1.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.txtpass1.FocusedState.Parent = this.txtpass1;
            this.txtpass1.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtpass1.HoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.txtpass1.HoverState.Parent = this.txtpass1;
            this.txtpass1.IconLeft = ((System.Drawing.Image)(resources.GetObject("txtpass1.IconLeft")));
            this.txtpass1.IconLeftOffset = new System.Drawing.Point(5, 0);
            this.txtpass1.Location = new System.Drawing.Point(512, 130);
            this.txtpass1.Margin = new System.Windows.Forms.Padding(6);
            this.txtpass1.Name = "txtpass1";
            this.txtpass1.PasswordChar = '\0';
            this.txtpass1.PlaceholderForeColor = System.Drawing.SystemColors.ControlDarkDark;
            this.txtpass1.PlaceholderText = "Password";
            this.txtpass1.SelectedText = "";
            this.txtpass1.ShadowDecoration.Parent = this.txtpass1;
            this.txtpass1.Size = new System.Drawing.Size(266, 46);
            this.txtpass1.TabIndex = 10;
            this.txtpass1.UseSystemPasswordChar = true;
            // 
            // txtpnome
            // 
            this.txtpnome.Animated = true;
            this.txtpnome.AutoRoundedCorners = true;
            this.txtpnome.BorderColor = System.Drawing.SystemColors.ControlDark;
            this.txtpnome.BorderRadius = 22;
            this.txtpnome.BorderThickness = 2;
            this.txtpnome.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.txtpnome.DefaultText = "";
            this.txtpnome.DisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(208)))), ((int)(((byte)(208)))));
            this.txtpnome.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(226)))), ((int)(((byte)(226)))));
            this.txtpnome.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.txtpnome.DisabledState.Parent = this.txtpnome;
            this.txtpnome.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.txtpnome.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.txtpnome.FocusedState.Parent = this.txtpnome;
            this.txtpnome.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtpnome.HoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.txtpnome.HoverState.Parent = this.txtpnome;
            this.txtpnome.IconLeft = ((System.Drawing.Image)(resources.GetObject("txtpnome.IconLeft")));
            this.txtpnome.IconLeftOffset = new System.Drawing.Point(5, 0);
            this.txtpnome.Location = new System.Drawing.Point(512, 73);
            this.txtpnome.Margin = new System.Windows.Forms.Padding(6);
            this.txtpnome.Name = "txtpnome";
            this.txtpnome.PasswordChar = '\0';
            this.txtpnome.PlaceholderForeColor = System.Drawing.SystemColors.ControlDarkDark;
            this.txtpnome.PlaceholderText = "Primeiro Nome";
            this.txtpnome.SelectedText = "";
            this.txtpnome.ShadowDecoration.Parent = this.txtpnome;
            this.txtpnome.Size = new System.Drawing.Size(150, 46);
            this.txtpnome.TabIndex = 11;
            // 
            // picbox1
            // 
            this.picbox1.Image = ((System.Drawing.Image)(resources.GetObject("picbox1.Image")));
            this.picbox1.Location = new System.Drawing.Point(89, 60);
            this.picbox1.Margin = new System.Windows.Forms.Padding(2);
            this.picbox1.Name = "picbox1";
            this.picbox1.ShadowDecoration.Parent = this.picbox1;
            this.picbox1.Size = new System.Drawing.Size(327, 387);
            this.picbox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.picbox1.TabIndex = 6;
            this.picbox1.TabStop = false;
            // 
            // txtunome
            // 
            this.txtunome.Animated = true;
            this.txtunome.AutoRoundedCorners = true;
            this.txtunome.BorderColor = System.Drawing.SystemColors.ControlDark;
            this.txtunome.BorderRadius = 22;
            this.txtunome.BorderThickness = 2;
            this.txtunome.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.txtunome.DefaultText = "";
            this.txtunome.DisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(208)))), ((int)(((byte)(208)))));
            this.txtunome.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(226)))), ((int)(((byte)(226)))));
            this.txtunome.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.txtunome.DisabledState.Parent = this.txtunome;
            this.txtunome.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.txtunome.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.txtunome.FocusedState.Parent = this.txtunome;
            this.txtunome.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtunome.HoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.txtunome.HoverState.Parent = this.txtunome;
            this.txtunome.IconLeft = ((System.Drawing.Image)(resources.GetObject("txtunome.IconLeft")));
            this.txtunome.IconLeftOffset = new System.Drawing.Point(5, 0);
            this.txtunome.Location = new System.Drawing.Point(665, 73);
            this.txtunome.Margin = new System.Windows.Forms.Padding(6);
            this.txtunome.Name = "txtunome";
            this.txtunome.PasswordChar = '\0';
            this.txtunome.PlaceholderForeColor = System.Drawing.SystemColors.ControlDarkDark;
            this.txtunome.PlaceholderText = "Ultimo";
            this.txtunome.SelectedText = "";
            this.txtunome.ShadowDecoration.Parent = this.txtunome;
            this.txtunome.Size = new System.Drawing.Size(113, 46);
            this.txtunome.TabIndex = 11;
            // 
            // txtpass2
            // 
            this.txtpass2.Animated = true;
            this.txtpass2.AutoRoundedCorners = true;
            this.txtpass2.BorderColor = System.Drawing.SystemColors.ControlDark;
            this.txtpass2.BorderRadius = 22;
            this.txtpass2.BorderThickness = 2;
            this.txtpass2.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.txtpass2.DefaultText = "";
            this.txtpass2.DisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(208)))), ((int)(((byte)(208)))));
            this.txtpass2.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(226)))), ((int)(((byte)(226)))));
            this.txtpass2.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.txtpass2.DisabledState.Parent = this.txtpass2;
            this.txtpass2.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.txtpass2.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.txtpass2.FocusedState.Parent = this.txtpass2;
            this.txtpass2.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtpass2.HoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.txtpass2.HoverState.Parent = this.txtpass2;
            this.txtpass2.IconLeft = ((System.Drawing.Image)(resources.GetObject("txtpass2.IconLeft")));
            this.txtpass2.IconLeftOffset = new System.Drawing.Point(5, 0);
            this.txtpass2.Location = new System.Drawing.Point(512, 188);
            this.txtpass2.Margin = new System.Windows.Forms.Padding(6);
            this.txtpass2.Name = "txtpass2";
            this.txtpass2.PasswordChar = '\0';
            this.txtpass2.PlaceholderForeColor = System.Drawing.SystemColors.ControlDarkDark;
            this.txtpass2.PlaceholderText = "Password";
            this.txtpass2.SelectedText = "";
            this.txtpass2.ShadowDecoration.Parent = this.txtpass2;
            this.txtpass2.Size = new System.Drawing.Size(266, 46);
            this.txtpass2.TabIndex = 10;
            this.txtpass2.UseSystemPasswordChar = true;
            // 
            // txtuser
            // 
            this.txtuser.Animated = true;
            this.txtuser.AutoRoundedCorners = true;
            this.txtuser.BorderColor = System.Drawing.SystemColors.ControlDark;
            this.txtuser.BorderRadius = 22;
            this.txtuser.BorderThickness = 2;
            this.txtuser.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.txtuser.DefaultText = "";
            this.txtuser.DisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(208)))), ((int)(((byte)(208)))));
            this.txtuser.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(226)))), ((int)(((byte)(226)))));
            this.txtuser.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.txtuser.DisabledState.Parent = this.txtuser;
            this.txtuser.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.txtuser.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.txtuser.FocusedState.Parent = this.txtuser;
            this.txtuser.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtuser.HoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.txtuser.HoverState.Parent = this.txtuser;
            this.txtuser.IconLeft = ((System.Drawing.Image)(resources.GetObject("txtuser.IconLeft")));
            this.txtuser.IconLeftOffset = new System.Drawing.Point(5, 0);
            this.txtuser.Location = new System.Drawing.Point(512, 246);
            this.txtuser.Margin = new System.Windows.Forms.Padding(6);
            this.txtuser.Name = "txtuser";
            this.txtuser.PasswordChar = '\0';
            this.txtuser.PlaceholderForeColor = System.Drawing.SystemColors.ControlDarkDark;
            this.txtuser.PlaceholderText = "Username";
            this.txtuser.SelectedText = "";
            this.txtuser.ShadowDecoration.Parent = this.txtuser;
            this.txtuser.Size = new System.Drawing.Size(266, 46);
            this.txtuser.TabIndex = 10;
            // 
            // errorProvider1
            // 
            this.errorProvider1.ContainerControl = this;
            // 
            // SignUp
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(96F, 96F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Dpi;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(919, 575);
            this.Controls.Add(this.guna2CircleButton3);
            this.Controls.Add(this.guna2CircleButton2);
            this.Controls.Add(this.guna2CircleButton1);
            this.Controls.Add(this.bttsign);
            this.Controls.Add(this.txtuser);
            this.Controls.Add(this.txtpass2);
            this.Controls.Add(this.txtpass1);
            this.Controls.Add(this.txtunome);
            this.Controls.Add(this.txtpnome);
            this.Controls.Add(this.picbox1);
            this.Margin = new System.Windows.Forms.Padding(2);
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "SignUp";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Sign Up";
            this.Load += new System.EventHandler(this.SignUp_Load);
            ((System.ComponentModel.ISupportInitialize)(this.picbox1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.errorProvider1)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private Guna.UI2.WinForms.Guna2CircleButton guna2CircleButton3;
        private Guna.UI2.WinForms.Guna2CircleButton guna2CircleButton2;
        private Guna.UI2.WinForms.Guna2CircleButton guna2CircleButton1;
        private Guna.UI2.WinForms.Guna2GradientButton bttsign;
        private Guna.UI2.WinForms.Guna2TextBox txtpass1;
        private Guna.UI2.WinForms.Guna2TextBox txtpnome;
        private Guna.UI2.WinForms.Guna2PictureBox picbox1;
        private Guna.UI2.WinForms.Guna2TextBox txtunome;
        private Guna.UI2.WinForms.Guna2TextBox txtpass2;
        private Guna.UI2.WinForms.Guna2TextBox txtuser;
        private System.Windows.Forms.ErrorProvider errorProvider1;
    }
}