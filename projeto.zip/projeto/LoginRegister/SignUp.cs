﻿using DAL;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using DataEntity;


namespace LoginRegister
{
    public partial class SignUp : Form
    {
        public SignUp()
        {
            InitializeComponent();
        }

        private void SignUp_Load(object sender, EventArgs e)
        {

        }
        private bool validar()
        {
            bool erro = true;
            errorProvider1.Clear();

            if (txtuser.Text == "")
            {
                erro = false;
                errorProvider1.SetError(txtuser, "Erro no user");
            }
            if (txtpnome.Text == "")
            {
                erro = false;
                errorProvider1.SetError(txtuser, "Erro no nome");
            }
            if (txtpass1.Text == "")
            {
                erro = false;
                errorProvider1.SetError(txtpass1, "Erro na pass");
                errorProvider1.SetError(txtpass2, "Erro na pass");
            }
            if (txtpass2.Text == "")
            {
                erro = false;
                errorProvider1.SetError(txtpass1, "Erro na pass");
                errorProvider1.SetError(txtpass2, "Erro na pass");
            }
            if (txtpass1.Text != txtpass2.Text)
            {
                erro = false;

            }
            return erro;
        }
        private void bttsign_Click(object sender, EventArgs e)
        {
            if (validar())
            {
                int qtdnomes = UtilizadorDAL.ContarUtilizadoresNome(txtuser.Text);

                if (qtdnomes != 0)
                {
                    MessageBox.Show("Utilizador ja existe,Tente novamente");
                    txtuser.ResetText();
                }
                else
                {
                    Utilizadores u = new Utilizadores(txtuser.Text,txtpnome.Text,txtunome.Text, txtpass1.Text);
                    UtilizadorDAL.InserirUtilizador(u);
                    Close();
                }
            }
        }
    }
}
