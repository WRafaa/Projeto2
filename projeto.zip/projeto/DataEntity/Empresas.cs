﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DataEntity
{
    public class Empresas
    {
        int id,idcontacto;
        string nome, morada;

        public int Id { get => Id1; set => Id1 = value; }
        public string Nome { get => nome; set => nome = value; }
        public string Morada { get => morada; set => morada = value; }
        public int Id1 { get => id; set => id = value; }
        public int Idcontacto { get => idcontacto; set => idcontacto = value; }


        //Metodo para editar/apagar
        public Empresas(int id,string nome,string morada,int idcon)
        { 
            this.Id1 = id;
            this.nome = nome;
            this.morada = morada;
            this.idcontacto = idcon;
        }
        //metodo para inserir na tabela
        public Empresas(string nome, string morada,int con) 
        { 
            this.nome=nome;
            this.morada=morada;
            this.Idcontacto = con;
        }

    }

}
