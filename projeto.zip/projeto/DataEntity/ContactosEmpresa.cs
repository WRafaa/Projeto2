﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DataEntity
{
    public class ContactosEmpresa
    {
        int id_emp, id_grupo;
        string pnome, unome, morada, empresa, grupo, contacto;

        public int Id_Emp { get => id_emp; set => id_emp = value; }
        public int Id_grupo { get => id_grupo; set => id_grupo = value; }
        public string Pnome { get => pnome; set => pnome = value; }
        public string Unome { get => unome; set => unome = value; }
        public string Morada { get => morada; set => morada = value; }
        public string Empresa { get => empresa; set => empresa = value; }
        public string Grupo { get => grupo; set => grupo = value; }
        public string Contacto { get => contacto; set => contacto = value; }

        public ContactosEmpresa(int emp,int grupo) 
        { 
            this.id_emp = emp;
            this.id_grupo= grupo;
        }
        public ContactosEmpresa(string pnome,string unome,string morada,string empresa,string grupo,string contacto)
        {
            this.Contacto = contacto;
            this.Pnome = pnome;
            this.Unome = unome;
            this.Morada = morada;
            this.Empresa = empresa; 
            this.Grupo = grupo;
        }
    }
}
