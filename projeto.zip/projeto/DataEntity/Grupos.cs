﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DataEntity
{
    public class Grupos
    {
        int id_grupo;
        string designacao;

        public int Id_grupo { get => id_grupo; set => id_grupo = value; }
        public string Designacao { get => designacao; set => designacao = value; }

        //Metodo para editar/apagar
        public Grupos(int id,string desi)
        {
            this.id_grupo = id;
            this.designacao = desi;
        }

        //metodo para inserir na tabela

        public Grupos(string desi)
        {
            this.designacao = desi;
        }
    }
}
