﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DataEntity
{
    public class Utilizadores
    {
        string nome, pin,user,nomeU;

        public string Nome { get => nome; set => nome = value; }
        public string Pin { get => pin; set => pin = value; }
        public string User { get => user; set => user = value; }
        public string NomeU { get => nomeU; set => nomeU = value; }

        public Utilizadores(string user,string pnome,string unome, string pin)
        {
            this.user = user;
            this.nomeU = unome;
            this.nome = pnome;
            this.pin = pin;
        }
    }
}
