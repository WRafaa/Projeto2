﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DataEntity
{
    public class Contactos
    {
        int id;
        string tipo, contacto;

        public int Id { get => id; set => id = value; }
        public string Tipo { get => tipo; set => tipo = value; }
        public string Contacto { get => contacto; set => contacto = value; }

        public Contactos(string t,string c) 
        { 
            this.Tipo = t; 
            this.Contacto = c;
        }
        public Contactos(int id, string t, string c)
        {
            this.Id = id;
            this.Tipo = t;
            this.Contacto = c;
        }
    }
}
