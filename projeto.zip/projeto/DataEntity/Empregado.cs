﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DataEntity
{
    public class Empregado
    {
        int id_emp, id_empresa, id_contacto;
        string pnome, unome, morada, contacto, empresa;

        public int Id_emp { get => id_emp; set => id_emp = value; }
        public int Id_empresa { get => id_empresa; set => id_empresa = value; }
        public int Id_contacto { get => id_contacto; set => id_contacto = value; }
        public string Pnome { get => pnome; set => pnome = value; }
        public string Unome { get => unome; set => unome = value; }
        public string Morada { get => morada; set => morada = value; }
        public string Contacto { get => contacto; set => contacto = value; }
        public string Empresa { get => empresa; set => empresa = value; }

        //metodo para criar na tabela empregados
        public Empregado(string pnome, string unome, string morada, int id_empresa, int id_contacto)
        {
            this.Pnome = pnome;
            this.Unome = unome;
            this.Morada = morada;
            this.id_empresa = id_empresa;
            this.id_contacto = id_contacto;

        }
        //metodo para consultar na dgv
        public Empregado(int idempregado,string pnome ,string morada, string empresa, string contacto)
        {
            this.id_emp=idempregado;
            this.Pnome = pnome;
            this.Morada = morada;
            this.empresa = empresa;
            this.contacto = contacto;
        }
        //para editar
        public Empregado(int idempregado, string pnome,string unome, string morada, int idemp, int idcontacto)
        {
            this.id_emp = idempregado;
            this.Pnome = pnome;
            this.unome = unome;
            this.Morada = morada;
            this.id_empresa = idemp;
            this.id_contacto = idcontacto;
        }
    }
}
