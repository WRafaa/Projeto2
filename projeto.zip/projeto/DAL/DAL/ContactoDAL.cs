﻿using DataEntity;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DAL
{
   public class ContactoDAL
    {
        public static void InserirContacto(Contactos c)
        {
            string query = "Insert into Contacto(Tipo_Contacto,Contacto) values (@tipo,@con); ";

            using (SqlConnection connection = new SqlConnection(BDDAL.Connectionstring))
            {
                try
                {
                    SqlCommand cmd = new SqlCommand(query, connection);
                    connection.Open();

                    SqlParameter paramTipo = new SqlParameter("@tipo", c.Tipo);
                    cmd.Parameters.Add(paramTipo);

                    SqlParameter paramCon = new SqlParameter("@con", c.Contacto);
                    cmd.Parameters.Add(paramCon);


                    //Executa o comando (Insert,delete,update)
                    //neste caso insert
                    cmd.ExecuteNonQuery();
                }
                catch (SqlException)
                {
                    throw;
                }
                catch (Exception)
                {
                    throw;
                }
            }
        }
        public static List<Contactos> Consultar()
        {

            List<Contactos> list = new List<Contactos>();
            string query = "select * from Contacto ";
            try
            {
                DataTable dt = BDDAL.ConsultarDados(query);
                if (dt != null)
                {
                    foreach (DataRow row in dt.Rows)
                    {
                        Contactos c = new Contactos(row.Field<Int32>("Id_Contacto"),
                            row.Field<string>("tipo_Contacto"), row.Field<string>("Contacto"));
                        list.Add(c);
                    }
                }
            }
            catch (SqlException)
            {
                throw;
            }
            catch (Exception)
            {
                throw;
            }
            return list;
        }
        public static void AtualizarContacto(Contactos c)
        {
            string query = "update Contacto set Contacto= @con where Id_Contacto=@id;";
            using (SqlConnection connection = new SqlConnection(BDDAL.Connectionstring))
            {
                try
                {
                    SqlCommand cmd = new SqlCommand(query, connection);
                    connection.Open();

                    //Executa o comando (Insert,delete,update)
                    //neste caso insert

                    SqlParameter paramId = new SqlParameter("@id", c.Id);
                    cmd.Parameters.Add(paramId);

                    SqlParameter paramCon = new SqlParameter("@con", c.Contacto);
                    cmd.Parameters.Add(paramCon);

                    cmd.ExecuteNonQuery();
                }
                catch (SqlException)
                {
                    throw;
                }
                catch (Exception)
                {
                    throw;
                }
            }


        }
        public static List<Contactos> ConsultarCodigo(int id)
        {
            List<Contactos> lista = new List<Contactos>();
            string query = "select Id_Contacto,Tipo_Contacto,Contacto" +
                " from Contacto where Id_Contacto= @id;";
            using (SqlConnection connection = new SqlConnection(BDDAL.Connectionstring))
            {

                SqlCommand cmd = new SqlCommand(query, connection);
                connection.Open();

                SqlParameter paramCodigo = new SqlParameter("@id", id);
                cmd.Parameters.Add(paramCodigo);

                try
                {
                    DataTable dt = new DataTable(); ;
                    SqlDataReader sdr = cmd.ExecuteReader();
                    if (sdr.HasRows)
                    {
                        //preenche uma datatable com os valores da base de dados
                        //usando o data reader
                        dt.Load(sdr);
                    }
                    sdr.Close();
                    if (dt != null)
                    {
                        foreach (DataRow row in dt.Rows)
                        {
                            Contactos c = new Contactos(row.Field<Int32>("Id_Contacto"),
                            row.Field<string>("Tipo_Contacto"), row.Field<string>("Contacto"));
                            lista.Add(c);
                        }

                    }
                }
                catch (SqlException)
                {
                    throw;
                }
                catch (Exception)
                {
                    throw;
                }
            }

            return lista;
        }
        public static void EliminarContacto(int codigo)
        {
            string query = "delete from Contacto where Id_Contacto=@id;";
            using (SqlConnection connection = new SqlConnection(BDDAL.Connectionstring))
            {
                try
                {
                    SqlCommand cmd = new SqlCommand(query, connection);
                    connection.Open();


                    SqlParameter paramCod = new SqlParameter("@id", codigo);
                    cmd.Parameters.Add(paramCod);

                    cmd.ExecuteNonQuery();
                }
                catch (SqlException)
                {
                    throw;
                }
                catch (Exception)
                {
                    throw;
                }
            }

        }
    }
   
}
