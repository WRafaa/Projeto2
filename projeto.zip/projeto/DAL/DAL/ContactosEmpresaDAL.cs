﻿using DataEntity;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DAL
{
    public class ContactosEmpresaDAL
    {
        public static void InserirEmpGrupo(ContactosEmpresa ep)
        {
            string query = "Insert into Emp_Grupo(Id_Empregado,Id_Grupo) values (@idemp,@idgrupo); ";

            using (SqlConnection connection = new SqlConnection(BDDAL.Connectionstring))
            {
                try
                {
                    SqlCommand cmd = new SqlCommand(query, connection);
                    connection.Open();

                    SqlParameter paramEmp = new SqlParameter("@idemp", ep.Id_Emp);
                    cmd.Parameters.Add(paramEmp);

                    SqlParameter paramCon = new SqlParameter("@idgrupo", ep.Id_grupo);
                    cmd.Parameters.Add(paramCon);


                    //Executa o comando (Insert,delete,update)
                    //neste caso insert
                    cmd.ExecuteNonQuery();
                }
                catch (SqlException)
                {
                    throw;
                }
                catch (Exception)
                {
                    throw;
                }
            }
        }
        public static List<string> ComboEmp()
        {
            List<string> list = new List<string>();
            string query = "select P_Nome from Empregado order by P_Nome";
            try
            {

                DataTable dt = BDDAL.ConsultarDados(query);
                if (dt != null)
                {
                    foreach (DataRow dr in dt.Rows)
                    {
                        list.Add(dr.Field<string>("P_Nome"));
                    }
                }

            }
            catch (SqlException)
            {
                throw;
            }
            catch (Exception)
            {
                throw;
            }
            return list;
        }
        public static List<string> ComboGrupo()
        {
            List<string> list = new List<string>();
            string query = "select Designacao from Grupo order by Designacao";
            try
            {

                DataTable dt = BDDAL.ConsultarDados(query);
                if (dt != null)
                {
                    foreach (DataRow dr in dt.Rows)
                    {
                        list.Add(dr.Field<string>("Designacao"));
                    }
                }

            }
            catch (SqlException)
            {
                throw;
            }
            catch (Exception)
            {
                throw;
            }
            return list;
        }
        public static int CodigoEmp(string txt)
        {
            int cod = 0;

            using (SqlConnection conn = new SqlConnection(BDDAL.Connectionstring))
            {
                try
                {
                    string query = "select Id_Empregado from Empregado where P_Nome=@nome";
                    SqlCommand cmd = new SqlCommand(query, conn);
                    conn.Open();

                    SqlParameter paramnome = new SqlParameter("@nome", txt);
                    cmd.Parameters.Add(paramnome);

                    DataTable dt = new DataTable();
                    SqlDataReader sdr = cmd.ExecuteReader();
                    if (sdr.HasRows)
                    {
                        //preenche uma datatable com os valores da base de dados
                        //usando o data reader
                        dt.Load(sdr);
                    }
                    sdr.Close();
                    if (dt != null)
                    {
                        foreach (DataRow row in dt.Rows)
                        {
                            cod = row.Field<Int32>("Id_Empregado");
                        }
                    }
                    else
                    {
                        throw new ArgumentException();
                    }

                }
                catch (SqlException)
                {
                    throw;
                }
                catch (Exception)
                {
                    throw;
                }
            }
            return cod;
        }
        public static int CodigoGrupo(string txt)
        {
            int cod = 0;

            using (SqlConnection conn = new SqlConnection(BDDAL.Connectionstring))
            {
                try
                {
                    string query = "select Id_Grupo from Grupo where Designacao=@nome";
                    SqlCommand cmd = new SqlCommand(query, conn);
                    conn.Open();

                    SqlParameter paramnome = new SqlParameter("@nome", txt);
                    cmd.Parameters.Add(paramnome);

                    DataTable dt = new DataTable();
                    SqlDataReader sdr = cmd.ExecuteReader();
                    if (sdr.HasRows)
                    {
                        //preenche uma datatable com os valores da base de dados
                        //usando o data reader
                        dt.Load(sdr);
                    }
                    sdr.Close();
                    if (dt != null)
                    {
                        foreach (DataRow row in dt.Rows)
                        {
                            cod = row.Field<Int32>("Id_grupo");
                        }
                    }
                    else
                    {
                        throw new ArgumentException();
                    }

                }
                catch (SqlException)
                {
                    throw;
                }
                catch (Exception)
                {
                    throw;
                }
            }
            return cod;
        }
        public static List<ContactosEmpresa> PesquisarEmp(string txt)
        {

            List<ContactosEmpresa> list = new List<ContactosEmpresa>();
            string query = "SELECT  dbo.Empregado.P_Nome, dbo.Empregado.U_Nome, dbo.Empregado.Morada, dbo.Empresa.Nome_Empresa, dbo.Grupo.Designacao, dbo.Contacto.Contacto FROM " +
                " dbo.Grupo RIGHT OUTER JOIN\r\n  dbo.Emp_grupo ON dbo.Grupo.Id_Grupo = dbo.Emp_grupo.Id_Grupo LEFT OUTER JOIN\r\n " +
                "  dbo.Empresa RIGHT OUTER JOIN\r\n   dbo.Empregado ON dbo.Empresa.Id_Empresa = dbo.Empregado.Id_Empresa LEFT OUTER JOIN\r\n " +
                " dbo.Contacto ON dbo.Empregado.Id_Contacto = dbo.Contacto.Id_contacto ON dbo.Emp_grupo.Id_Empregado = dbo.Empregado.Id_Empregado" +
                " where dbo.Empregado.P_Nome like '%" + txt +"%' ;";
            try
            {
                DataTable dt = BDDAL.ConsultarDados(query);
                if (dt != null)
                {
                    foreach (DataRow row in dt.Rows)
                    {
                       ContactosEmpresa c=new ContactosEmpresa(row.Field<string>("P_Nome"),
                            row.Field<string>("U_Nome"), row.Field<string>("Morada"), row.Field<string>("Nome_Empresa"), row.Field<string>("Designacao"), row.Field<string>("Contacto"));
                        list.Add(c);
                    }
                }
            }
            catch (SqlException)
            {
                throw;
            }
            catch (Exception)
            {
                throw;
            }
            return list;
        }
    }
}
