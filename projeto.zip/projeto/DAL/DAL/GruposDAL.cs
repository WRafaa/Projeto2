﻿using DataEntity;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DAL
{
    public class GruposDAL
    {
        public static void InserirGrupo(Grupos g)
        {
            string query = "Insert into Grupo(Designacao) values (@Designacao); ";

            using (SqlConnection connection = new SqlConnection(BDDAL.Connectionstring))
            {
                try
                {
                    SqlCommand cmd = new SqlCommand(query, connection);
                    connection.Open();

                    SqlParameter paramDesignacao = new SqlParameter("@Designacao", g.Designacao);
                    cmd.Parameters.Add(paramDesignacao);

                    //Executa o comando (Insert,delete,update)
                    //neste caso insert
                    cmd.ExecuteNonQuery();
                }
                catch (SqlException)
                {
                    throw;
                }
                catch (Exception)
                {
                    throw;
                }
            }
        }
        public static List<Grupos> Consultar()
        {

            List<Grupos> list = new List<Grupos>();
            string query = "select * from Grupo ";
            try
            {
                DataTable dt = BDDAL.ConsultarDados(query);
                if (dt != null)
                {
                    foreach (DataRow row in dt.Rows)
                    {
                        Grupos g = new Grupos(row.Field<Int32>("Id_Grupo"),
                            row.Field<string>("Designacao"));
                        list.Add(g);
                    }
                }
            }
            catch (SqlException)
            {
                throw;
            }
            catch (Exception)
            {
                throw;
            }
            return list;
        }
        public static void EliminarGrupo(int codigo)
        {
            string query = "delete from Grupo where Id_Grupo=@id;";
            using (SqlConnection connection = new SqlConnection(BDDAL.Connectionstring))
            {
                try
                {
                    SqlCommand cmd = new SqlCommand(query, connection);
                    connection.Open();


                    SqlParameter paramCod = new SqlParameter("@id", codigo);
                    cmd.Parameters.Add(paramCod);

                    cmd.ExecuteNonQuery();
                }
                catch (SqlException)
                {
                    throw;
                }
                catch (Exception)
                {
                    throw;
                }
            }

        }
        public static List<Grupos> ConsultarCodigo(int id)
        {
            List<Grupos> lista = new List<Grupos>();
            string query = "select Id_Grupo,Designacao" +
                " from Grupo where Id_Grupo= @id;";
            using (SqlConnection connection = new SqlConnection(BDDAL.Connectionstring))
            {

                SqlCommand cmd = new SqlCommand(query, connection);
                connection.Open();

                SqlParameter paramCodigo = new SqlParameter("@id", id);
                cmd.Parameters.Add(paramCodigo);

                try
                {
                    DataTable dt = new DataTable(); ;
                    SqlDataReader sdr = cmd.ExecuteReader();
                    if (sdr.HasRows)
                    {
                        //preenche uma datatable com os valores da base de dados
                        //usando o data reader
                        dt.Load(sdr);
                    }
                    sdr.Close();
                    if (dt != null)
                    {
                        foreach (DataRow row in dt.Rows)
                        {
                            Grupos d = new Grupos(row.Field<Int32>("Id_Grupo"),
                            row.Field<string>("Designacao"));
                            lista.Add(d);
                        }

                    }
                }
                catch (SqlException)
                {
                    throw;
                }
                catch (Exception)
                {
                    throw;
                }
            }

            return lista;
        }
        public static void Atualizargrupo(Grupos g)
        {
            string query = "update Grupo set Designacao= @Designacao where Id_Grupo=@id_grupo;";
            using (SqlConnection connection = new SqlConnection(BDDAL.Connectionstring))
            {
                try
                {
                    SqlCommand cmd = new SqlCommand(query, connection);
                    connection.Open();

                    //Executa o comando (Insert,delete,update)
                    //neste caso insert

                    SqlParameter paramCod = new SqlParameter("@id_grupo", g.Id_grupo);
                    cmd.Parameters.Add(paramCod);

                    SqlParameter paramDesignacao = new SqlParameter("@Designacao", g.Designacao);
                    cmd.Parameters.Add(paramDesignacao);

                    cmd.ExecuteNonQuery();
                }
                catch (SqlException)
                {
                    throw;
                }
                catch (Exception)
                {
                    throw;
                }
            }


        }
    }
}
