﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DAL
{
    public class BDDAL
    {
        static string connectionstring = @"Data Source=.\SQLExpress;"
                                       + "Initial Catalog=PAP;"
                                       + "Integrated Security=True;";

        public static string Connectionstring { get => connectionstring; set => connectionstring = value; }
        public static DataTable ConsultarDados(string query)
        {
            DataTable dt = null;

            using (SqlConnection sqlconn = new SqlConnection(Connectionstring))
            {
                try
                {
                    SqlCommand sqlcmd = new SqlCommand(query, sqlconn);
                    sqlconn.Open();

                    SqlDataReader sdr = sqlcmd.ExecuteReader();
                    if (sdr.HasRows)
                    {
                        dt = new DataTable();
                        //preenche uma datatable com os valores da base de dados
                        //usando o data reader
                        dt.Load(sdr);
                    }
                    sdr.Close();
                }
                catch (SqlException)
                {
                    throw;
                }
                catch (Exception)
                {
                    throw;
                }
            }
            return dt;
        }
        public static int ExecutarEscalar(string query)
        {
            int valor;
            using (SqlConnection conn = new SqlConnection(connectionstring))
            {
                try
                {
                    SqlCommand sqlcmd = new SqlCommand(query, conn);
                    conn.Open();

                    valor = (int)sqlcmd.ExecuteScalar();
                }
                catch (SqlException)
                {
                    throw;
                }
                catch (Exception)
                {
                    throw;
                }


            }
            return valor;
        }
    }
}
