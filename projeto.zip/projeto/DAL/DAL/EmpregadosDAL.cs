﻿using DataEntity;
using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DAL
{
    public class EmpregadosDAL
    {
        
       
        public static List<string> ComboEmpresa()
        {
            List<string> list = new List<string>();
            string query = "select Nome_Empresa from Empresa order by Nome_Empresa";
            try
            {

                DataTable dt = BDDAL.ConsultarDados(query);
                if (dt != null)
                {
                    foreach (DataRow dr in dt.Rows)
                    {
                        list.Add(dr.Field<string>("Nome_Empresa"));
                    }
                }

            }
            catch (SqlException)
            {
                throw;
            }
            catch (Exception)
            {
                throw;
            }
            return list;
        }
        public static List<string> ComboContacto()
        {
            List<string> list = new List<string>();
            string query = "select Contacto from Contacto order by Contacto";
            try
            {

                DataTable dt = BDDAL.ConsultarDados(query);
                if (dt != null)
                {
                    foreach (DataRow dr in dt.Rows)
                    {
                        list.Add(dr.Field<string>("Contacto"));
                    }
                }

            }
            catch (SqlException)
            {
                throw;
            }
            catch (Exception)
            {
                throw;
            }
            return list;
        }
        public static List<Empregado> ConsultarCodigo(int id)
        {
            List<Empregado> lista = new List<Empregado>();
            string query = "select Id_Empregado,P_Nome,U_Nome,Morada,Id_Empresa,Id_Contacto" +
                " from Empregado where Id_Empregado= @id;";
            using (SqlConnection connection = new SqlConnection(BDDAL.Connectionstring))
            {

                SqlCommand cmd = new SqlCommand(query, connection);
                connection.Open();

                SqlParameter paramCodigo = new SqlParameter("@id", id);
                cmd.Parameters.Add(paramCodigo);

                try
                {
                    DataTable dt = new DataTable();
                    SqlDataReader sdr = cmd.ExecuteReader();
                    if (sdr.HasRows)
                    {
                        //preenche uma datatable com os valores da base de dados
                        //usando o data reader
                        dt.Load(sdr);
                    }
                    sdr.Close();
                    if (dt != null)
                    {
                        foreach (DataRow row in dt.Rows)
                        {
                            Empregado E = new Empregado(row.Field<Int32>("Id_Empregado"),
                            row.Field<string>("P_Nome"), row.Field<string>("U_Nome"), row.Field<string>("Morada"), row.Field<Int32>("Id_Empresa")
                            , row.Field<Int32>("Id_Contacto"));
                            lista.Add(E);
                        }

                    }
                }
                catch (SqlException)
                {
                    throw;
                }
                catch (Exception)
                {
                    throw;
                }
            }

            return lista;
        }
        public static void InserirEmpregado(Empregado e)
        {
            string query = "Insert into Empregado(P_Nome,U_Nome,Morada,Id_Empresa,Id_Contacto) values (@pnome,@unome,@morada,@empresa,@con); ";

            using (SqlConnection connection = new SqlConnection(BDDAL.Connectionstring))
            {
                try
                {
                    SqlCommand cmd = new SqlCommand(query, connection);
                    connection.Open();

                    SqlParameter paramPNome = new SqlParameter("@pnome", e.Pnome);
                    cmd.Parameters.Add(paramPNome);

                    SqlParameter paramUNome = new SqlParameter("@UNome", e.Unome);
                    cmd.Parameters.Add(paramUNome);

                    SqlParameter paramMorada = new SqlParameter("@morada", e.Morada);
                    cmd.Parameters.Add(paramMorada);

                    SqlParameter paramempresa = new SqlParameter("@empresa", e.Id_empresa);
                    cmd.Parameters.Add(paramempresa);

                    SqlParameter paramcontacto = new SqlParameter("@con", e.Id_contacto);
                    cmd.Parameters.Add(paramcontacto);

                    //Executa o comando (Insert,delete,update)
                    //neste caso insert
                    cmd.ExecuteNonQuery();
                }
                catch (SqlException)
                {
                    throw;
                }
                catch (Exception)
                {
                    throw;
                }
            }
        }
        public static void EliminarEmpregado(int codigo)
        {
            string query = "delete from Empregado where Id_Empregado=@id;";
            using (SqlConnection connection = new SqlConnection(BDDAL.Connectionstring))
            {
                try
                {
                    SqlCommand cmd = new SqlCommand(query, connection);
                    connection.Open();


                    SqlParameter paramCod = new SqlParameter("@id", codigo);
                    cmd.Parameters.Add(paramCod);

                    cmd.ExecuteNonQuery();
                }
                catch (SqlException)
                {
                    throw;
                }
                catch (Exception)
                {
                    throw;
                }
            }

        }
        public static int CodigoEmp(string txt)
        {
            int cod = 0;

            using (SqlConnection conn = new SqlConnection(BDDAL.Connectionstring))
            {
                try
                {
                    string query = "select Id_Empresa from Empresa where Nome_Empresa=@nome";
                    SqlCommand cmd = new SqlCommand(query, conn);
                    conn.Open();

                    SqlParameter paramCodigo = new SqlParameter("@nome", txt);
                    cmd.Parameters.Add(paramCodigo);

                    DataTable dt = new DataTable();
                    SqlDataReader sdr = cmd.ExecuteReader();
                    if (sdr.HasRows)
                    {
                        //preenche uma datatable com os valores da base de dados
                        //usando o data reader
                        dt.Load(sdr);
                    }
                    sdr.Close();
                    if (dt != null)
                    {
                        foreach (DataRow row in dt.Rows)
                        {
                            cod = row.Field<Int32>("Id_Empresa");
                        }
                    }
                    else
                    {
                        throw new ArgumentException();
                    }

                }
                catch (SqlException)
                {
                    throw;
                }
                catch (Exception)
                {
                    throw;
                }
            }
            return cod;
        }
        public static int CodigoContacto(string txt)
        {
            int cod = 0;

            using (SqlConnection conn = new SqlConnection(BDDAL.Connectionstring))
            {
                try
                {
                    string query = "select Id_Contacto from Contacto where Contacto=@con";
                    SqlCommand cmd = new SqlCommand(query, conn);
                    conn.Open();

                    SqlParameter paramCodigo = new SqlParameter("@con", txt);
                    cmd.Parameters.Add(paramCodigo);

                    DataTable dt = new DataTable();
                    SqlDataReader sdr = cmd.ExecuteReader();
                    if (sdr.HasRows)
                    {
                        //preenche uma datatable com os valores da base de dados
                        //usando o data reader
                        dt.Load(sdr);
                    }
                    sdr.Close();
                    if (dt != null)
                    {
                        foreach (DataRow row in dt.Rows)
                        {
                            cod = row.Field<Int32>("Id_Contacto");
                        }
                    }
                    else
                    {
                        throw new ArgumentException();
                    }

                }
                catch (SqlException)
                {
                    throw;
                }
                catch (Exception)
                {
                    throw;
                }
            }
            return cod;
        }
        public static string NomeEmpresa(int cod)
        {
            string nome="";

            using (SqlConnection conn = new SqlConnection(BDDAL.Connectionstring))
            {
                try
                {
                    string query = "select Nome_Empresa from Empresa where Id_Empresa=@id";
                    SqlCommand cmd = new SqlCommand(query, conn);
                    conn.Open();

                    SqlParameter paramCodigo = new SqlParameter("@id", cod);
                    cmd.Parameters.Add(paramCodigo);

                    DataTable dt = new DataTable();
                    SqlDataReader sdr = cmd.ExecuteReader();
                    if (sdr.HasRows)
                    {
                        //preenche uma datatable com os valores da base de dados
                        //usando o data reader
                        dt.Load(sdr);
                    }
                    sdr.Close();
                    if (dt != null)
                    {
                        foreach (DataRow row in dt.Rows)
                        {
                            nome = row.Field<string>("Nome_Empresa");
                        }
                    }
                    else
                    {
                        throw new ArgumentException();
                    }

                }
                catch (SqlException)
                {
                    throw;
                }
                catch (Exception)
                {
                    throw;
                }
            }
            return nome;
        }
        public static void AtualizarEmpregado(Empregado ep)
        {
            string query = "update Empregado set Morada=@morada,Id_Empresa=@id_empresa,Id_Contacto = @idcon where Id_Empregado = @id_emp;"; //and Id_Contacto != @idcon;";
            using (SqlConnection connection = new SqlConnection(BDDAL.Connectionstring))
            {
                try
                {
                    SqlCommand cmd = new SqlCommand(query, connection);
                    connection.Open();

                    //Executa o comando (Insert,delete,update)
                    //neste caso insert

                    SqlParameter paramCod = new SqlParameter("@id_emp",ep.Id_emp);
                    cmd.Parameters.Add(paramCod);

                    SqlParameter paramMorada = new SqlParameter("@morada", ep.Morada);
                    cmd.Parameters.Add(paramMorada);

                    SqlParameter paramEmpresa = new SqlParameter("@id_empresa", ep.Id_empresa);
                    cmd.Parameters.Add(paramEmpresa);

                    SqlParameter paramConn = new SqlParameter("@idcon", ep.Id_contacto);
                    cmd.Parameters.Add(paramConn);

                    cmd.ExecuteNonQuery();
                }
                catch (SqlException)
                {
                    throw;
                    
                }
                catch (Exception)
                {
                    throw;
                }
            }


        }
        public static int ContarEmpOrg()
        {
            int qtdemp;
            string query = "select count(*) from Empregado";

            try
            {
                qtdemp = BDDAL.ExecutarEscalar(query);
            }
            catch (SqlException)
            {
                throw;
            }
            catch (Exception)
            {
                throw;
            }
            return qtdemp;
        }
        public static string Contactoinfo(int cod)
        {
            string nome = "";

            using (SqlConnection conn = new SqlConnection(BDDAL.Connectionstring))
            {
                try
                {
                    string query = "select Contacto from Contacto where Id_Contacto=@id";
                    SqlCommand cmd = new SqlCommand(query, conn);
                    conn.Open();

                    SqlParameter paramCodigo = new SqlParameter("@id", cod);
                    cmd.Parameters.Add(paramCodigo);

                    DataTable dt = new DataTable();
                    SqlDataReader sdr = cmd.ExecuteReader();
                    if (sdr.HasRows)
                    {
                        //preenche uma datatable com os valores da base de dados
                        //usando o data reader
                        dt.Load(sdr);
                    }
                    sdr.Close();
                    if (dt != null)
                    {
                        foreach (DataRow row in dt.Rows)
                        {
                            nome = row.Field<string>("Contacto");
                        }
                    }
                    else
                    {
                        throw new ArgumentException();
                    }

                }
                catch (SqlException)
                {
                    throw;
                }
                catch (Exception)
                {
                    throw;
                }
            }
            return nome;
        }
    }
}
