﻿using DataEntity;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DAL
{
    public class EmpresasDAL
    {
        public static void InserirEmpresa(Empresas e)
        {
            string query = "Insert into Empresa(Nome_Empresa,Morada_Empresa,Id_Contacto) values (@nome,@morada,@id); ";

            using (SqlConnection connection = new SqlConnection(BDDAL.Connectionstring))
            {
                try
                {
                    SqlCommand cmd = new SqlCommand(query, connection);
                    connection.Open();

                    SqlParameter paramNome = new SqlParameter("@nome", e.Nome);
                    cmd.Parameters.Add(paramNome);

                    SqlParameter paramMorada = new SqlParameter("@morada", e.Morada);
                    cmd.Parameters.Add(paramMorada);

                    SqlParameter paramContacto = new SqlParameter("@id", e.Idcontacto);
                    cmd.Parameters.Add(paramContacto);

                    //Executa o comando (Insert,delete,update)
                    //neste caso insert
                    cmd.ExecuteNonQuery();
                }
                catch (SqlException)
                {
                    throw;
                }
                catch (Exception)
                {
                    throw;
                }
            }
        }
        public static int CodigoContacto(string txt)
        {
            int cod = 0;

            using (SqlConnection conn = new SqlConnection(BDDAL.Connectionstring))
            {
                try
                {
                    string query = "select Id_Contacto from Contacto where Contacto=@con";
                    SqlCommand cmd = new SqlCommand(query, conn);
                    conn.Open();

                    SqlParameter paramCodigo = new SqlParameter("@con", txt);
                    cmd.Parameters.Add(paramCodigo);

                    DataTable dt = new DataTable();
                    SqlDataReader sdr = cmd.ExecuteReader();
                    if (sdr.HasRows)
                    {
                        //preenche uma datatable com os valores da base de dados
                        //usando o data reader
                        dt.Load(sdr);
                    }
                    sdr.Close();
                    if (dt != null)
                    {
                        foreach (DataRow row in dt.Rows)
                        {
                            cod = row.Field<Int32>("Id_Contacto");
                        }
                    }
                    else
                    {
                        throw new ArgumentException();
                    }

                }
                catch (SqlException)
                {
                    throw;
                }
                catch (Exception)
                {
                    throw;
                }
            }
            return cod;
        }
        public static List<string> ComboContacto()
        {
            List<string> list = new List<string>();
            string query = "select Contacto from Contacto order by Contacto";
            try
            {

                DataTable dt = BDDAL.ConsultarDados(query);
                if (dt != null)
                {
                    foreach (DataRow dr in dt.Rows)
                    {
                        list.Add(dr.Field<string>("Contacto"));
                    }
                }

            }
            catch (SqlException)
            {
                throw;
            }
            catch (Exception)
            {
                throw;
            }
            return list;
        }
        public static List<Empresas> Consultar()
        {

            List<Empresas> list = new List<Empresas>();
            string query = "select * from Empresa ";
            try
            {
                DataTable dt = BDDAL.ConsultarDados(query);
                if (dt != null)
                {
                    foreach (DataRow row in dt.Rows)
                    {
                        Empresas E = new Empresas(row.Field<Int32>("Id_Empresa"),
                            row.Field<string>("Nome_Empresa"), row.Field<string>("Morada_Empresa"), row.Field<Int32>("Id_Contacto"));
                        list.Add(E);
                    }
                }
            }
            catch (SqlException)
            {
                throw;
            }
            catch (Exception)
            {
                throw;
            }
            return list;
        }
       
        public static void EliminarEmpresa(int codigo)
        {
            string query = "delete from Empresa where Id_Empresa=@id;";
            using (SqlConnection connection = new SqlConnection(BDDAL.Connectionstring))
            {
                try
                {
                    SqlCommand cmd = new SqlCommand(query, connection);
                    connection.Open();


                    SqlParameter paramCod = new SqlParameter("@id", codigo);
                    cmd.Parameters.Add(paramCod);

                    cmd.ExecuteNonQuery();
                }
                catch (SqlException)
                {
                    throw;
                }
                catch (Exception)
                {
                    throw;
                }
            }

        }
        public static List<Empresas> ConsultarCodigo(int id)
        {
            List<Empresas> lista = new List<Empresas>();
            string query = "select Id_Empresa,Nome_Empresa,Morada_Empresa,Id_Contacto" +
                " from Empresa where Id_Empresa= @id;";
            using (SqlConnection connection = new SqlConnection(BDDAL.Connectionstring))
            {

                SqlCommand cmd = new SqlCommand(query, connection);
                connection.Open();

                SqlParameter paramCodigo = new SqlParameter("@id", id);
                cmd.Parameters.Add(paramCodigo);

                try
                {
                    DataTable dt = new DataTable(); 
                    SqlDataReader sdr = cmd.ExecuteReader();
                    if (sdr.HasRows)
                    {
                        //preenche uma datatable com os valores da base de dados
                        //usando o data reader
                        dt.Load(sdr);
                    }
                    sdr.Close();
                    if (dt != null)
                    {
                        foreach (DataRow row in dt.Rows)
                        {
                            Empresas E = new Empresas(row.Field<Int32>("Id_Empresa"),
                            row.Field<string>("Nome_Empresa"), row.Field<string>("Morada_Empresa"), row.Field<Int32>("Id_Contacto"));
                            lista.Add(E);
                        }

                    }
                }
                catch (SqlException)
                {
                    throw;
                }
                catch (Exception)
                {
                    throw;
                }
            }

            return lista;
        }
    }
}
