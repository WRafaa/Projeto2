﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using DataEntity;
namespace DAL
{
    public class UtilizadorDAL
    {
        public static int ContarUtilizadoresNome(string nome)
        {
            int qtd;
            using (SqlConnection conn = new SqlConnection(BDDAL.Connectionstring))
            {
                string query = "select count(*) from Utilizadores where Username=@Username";
                SqlCommand cmd = new SqlCommand(query, conn);
                conn.Open();

                SqlParameter paranome = new SqlParameter("@Username", nome);
                cmd.Parameters.Add(paranome);

                qtd = (int)cmd.ExecuteScalar();


            }
            return qtd;
        }
        public static int ContarUtilizadoresNomePin(string nome, string pin)
        {
            int qtd;
            using (SqlConnection conn = new SqlConnection(BDDAL.Connectionstring))
            {
                string query = "select count(*) from Utilizadores where Username=@username and Pass=@Pass";
                SqlCommand cmd = new SqlCommand(query, conn);

                conn.Open();
                SqlParameter paranome = new SqlParameter("@username", nome);
                cmd.Parameters.Add(paranome);
                SqlParameter parapin = new SqlParameter("@Pass", pin);
                cmd.Parameters.Add(parapin);
                qtd = (int)cmd.ExecuteScalar();


            }
            return qtd;
        }
        public static void InserirUtilizador(Utilizadores u)
        {
            using (SqlConnection conn = new SqlConnection(BDDAL.Connectionstring))
            {
                string query = "INSERT INTO Utilizadores (Username,P_Nome,U_Nome,Pass) VALUES (@Username,@P_Nome,@U_Nome,@Pass)";

                SqlCommand cmd = new SqlCommand(query, conn);
                conn.Open();

                SqlParameter parauser = new SqlParameter("@Username", u.User);
                cmd.Parameters.Add(parauser);

                SqlParameter paranome = new SqlParameter("@P_Nome", u.Nome);
                cmd.Parameters.Add(paranome);

                SqlParameter paranomeU = new SqlParameter("@U_Nome", u.NomeU);
                cmd.Parameters.Add(paranomeU);

                SqlParameter parapin = new SqlParameter("@Pass", u.Pin);
                cmd.Parameters.Add(parapin);

                cmd.ExecuteNonQuery();
            }
        }
    }
}
