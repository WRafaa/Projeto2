/****** Script for SelectTopNRows command from SSMS  ******/
SELECT TOP (1000) [Id_Interacao]
      ,[Id_Empregado]
      ,[Data_Interacao]
      ,[Tipo_Interacao]
  FROM [PAP].[dbo].[Interacoes]